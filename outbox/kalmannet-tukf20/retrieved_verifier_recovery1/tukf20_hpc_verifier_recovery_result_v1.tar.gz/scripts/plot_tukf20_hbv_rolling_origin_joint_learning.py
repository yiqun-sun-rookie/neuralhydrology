"""Create figures only from independently verified TUKF20 evidence."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Mapping

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf20_hbv_rolling_origin_joint_learning_common as common  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
MODE_COLORS = {
    "all_frozen": "#6b7280",
    "hydrology_only": "#2563eb",
    "filter_only": "#16a34a",
    "joint": "#dc2626",
}


def _load_npz(path: Path | str) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def _representative_pair(verification: Mapping[str, Any]) -> dict[str, Any]:
    contrast = verification["independent_aggregates"]["primary"]["contrasts"][
        "joint_over_all_frozen"
    ]
    median = float(contrast["median_ratio"])
    selected = min(
        contrast["per_pair_ratios"],
        key=lambda row: (
            abs(float(row["ratio"]) - median),
            int(row["truth_seed"]),
            str(row["start_id"]),
        ),
    )
    return {
        "truth_seed": int(selected["truth_seed"]),
        "start_id": str(selected["start_id"]),
        "joint_over_all_frozen_ratio": float(selected["ratio"]),
        "registered_median_ratio": median,
        "selection_rule": (
            "minimum absolute distance to the registered joint-over-all-frozen "
            "median, then truth seed, then start identifier"
        ),
    }


def _labels(contract: Mapping[str, Any]) -> dict[str, str]:
    defaults = {
        "all_frozen": "State updates, both parameter groups frozen",
        "hydrology_only": "State updates, hydrologic parameters learned",
        "filter_only": "State updates, noise parameters learned",
        "joint": "State updates, both parameter groups learned",
        "joint_over_all_frozen": "Joint / both frozen",
        "joint_over_hydrology_only": "Joint / hydrologic only",
        "joint_over_filter_only": "Joint / noise only",
    }
    display_labels = contract.get("display_labels", {})
    for group in ("modes", "primary_contrasts"):
        defaults.update(
            {str(k): str(v) for k, v in display_labels.get(group, {}).items()}
        )
    return defaults


def _save_figure(path: Path) -> None:
    plt.tight_layout()
    plt.savefig(path, dpi=180, bbox_inches="tight")
    plt.close()


def generate_figures(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    common.validate_contract(contract, configuration_path=contract_path)
    result_root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    figure_root = common.resolve_output_path(contract, contract["outputs"]["figure_root"])
    if figure_root.exists():
        raise FileExistsError(f"refusing to replace TUKF20 figure root: {figure_root}")
    registry_path = result_root / "registry.json"
    root_manifest_path = result_root / "manifest.json"
    verification_path = result_root / "independent_verification.json"
    registry = common.read_json(registry_path)
    root_manifest = common.read_json(root_manifest_path)
    verification = common.read_json(verification_path)
    if registry.get("status") != "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION":
        raise PermissionError("TUKF20 registry is not a complete formal product")
    if verification.get("status") != "FORMAL_VERIFIED" or not all(
        bool(value) for value in verification.get("checks", {}).values()
    ):
        raise PermissionError("figures require a fully verified TUKF20 result")
    if (
        verification.get("registry_sha256") != common.sha256_file(registry_path)
        or verification.get("root_manifest_sha256")
        != common.sha256_file(root_manifest_path)
        or verification.get("selection_seal_sha256")
        != common.sha256_file(result_root / "selection_seal.json")
    ):
        raise PermissionError("verified TUKF20 evidence changed before plotting")
    current_files = {
        path.relative_to(result_root).as_posix(): common.sha256_file(path)
        for path in sorted(result_root.rglob("*"))
        if path.is_file()
        and path.name not in {"manifest.json", "independent_verification.json"}
    }
    if root_manifest.get("files") != current_files:
        raise PermissionError("TUKF20 result files changed after verification")
    if not np.isfinite(
        [
            value["median_ratio"]
            for value in verification["independent_aggregates"]["primary"][
                "contrasts"
            ].values()
        ]
    ).all():
        raise ValueError("verified contrast values are non-finite")
    figure_root.mkdir(parents=True, exist_ok=False)
    labels = _labels(contract)
    primary_order = list(contract["primary_contrasts"])
    primary = verification["independent_aggregates"]["primary"]["contrasts"]
    files: list[Path] = []

    ratio_path = figure_root / "primary_paired_error_ratios.png"
    plt.figure(figsize=(9.0, 4.8))
    values = [primary[name]["ratios"] for name in primary_order]
    plt.boxplot(values, tick_labels=[labels[name] for name in primary_order], showfliers=True)
    plt.axhline(1.0, color="black", linewidth=1.0, linestyle="--", label="No difference")
    plt.axhline(
        float(contract["gates"]["clear_benefit_median_ratio_maximum"]),
        color="#dc2626",
        linewidth=1.0,
        linestyle=":",
        label="Registered median threshold",
    )
    plt.ylabel("Paired clean-discharge mean-squared-error ratio")
    plt.xticks(rotation=12, ha="right")
    plt.legend(frameon=False)
    _save_figure(ratio_path)
    files.append(ratio_path)

    lead_path = figure_root / "primary_ratios_by_forecast_lead.png"
    plt.figure(figsize=(9.0, 4.8))
    x = np.arange(len(common.LEADS), dtype=np.float64)
    width = 0.22
    for index, name in enumerate(primary_order):
        medians = [primary[name]["by_lead"][str(lead)]["median_ratio"] for lead in common.LEADS]
        plt.bar(
            x + (index - (len(primary_order) - 1) / 2.0) * width,
            medians,
            width,
            label=labels[name],
        )
    plt.axhline(1.0, color="black", linewidth=1.0, linestyle="--")
    plt.axhline(
        float(contract["gates"]["clear_benefit_median_ratio_maximum"]),
        color="#dc2626",
        linewidth=1.0,
        linestyle=":",
    )
    plt.xticks(x, [f"{lead}-day" for lead in common.LEADS])
    plt.ylabel("Median paired clean-discharge error ratio")
    plt.legend(frameon=False, fontsize=9)
    _save_figure(lead_path)
    files.append(lead_path)

    representative = _representative_pair(verification)
    seed = representative["truth_seed"]
    start_id = representative["start_id"]
    pair_root = result_root / "repetitions" / f"truth_{seed}__{start_id}"
    hydrograph_path = figure_root / "representative_four_mode_hydrographs.png"
    plt.figure(figsize=(11.0, 5.2))
    first = _load_npz(pair_root / "readouts" / common.READOUT_ORDER[0] / "arrays.npz")
    days = np.asarray(first["origins"], dtype=np.int64) + 1
    plt.plot(days, first["clean_targets"][:, 0], color="black", linewidth=2.0, label="Clean synthetic truth")
    plt.scatter(days, first["observed_targets"][:, 0], color="#9ca3af", s=10, alpha=0.7, label="Noisy observations")
    representative_forecasts: dict[str, list[float]] = {}
    for mode in common.READOUT_ORDER:
        arrays = _load_npz(pair_root / "readouts" / mode / "arrays.npz")
        representative_forecasts[mode] = np.asarray(
            arrays["forecasts"][:, 0], dtype=np.float64
        ).tolist()
        plt.plot(
            days,
            arrays["forecasts"][:, 0],
            color=MODE_COLORS[mode],
            linewidth=1.4,
            label=labels[mode],
        )
    plt.xlabel("Synthetic day")
    plt.ylabel("One-day-ahead discharge")
    plt.title(f"Representative pair: truth seed {seed}, {start_id}")
    plt.legend(frameon=False, ncol=2, fontsize=8)
    _save_figure(hydrograph_path)
    files.append(hydrograph_path)

    truth_values = common.build_start_values(
        contract, start_id, hydrology_source="truth", filter_source="truth"
    )
    selected = {
        mode: _load_npz(pair_root / "modes" / mode / "selected_checkpoint.npz")
        for mode in common.MODE_ORDER
    }
    hydrology_path = figure_root / "representative_hydrologic_coordinate_displacement.png"
    truth_hydrology = np.asarray(truth_values["hydrology_coordinates"], dtype=np.float64).reshape(-1)
    learned_modes = ("hydrology_only", "joint")
    hydrology_displacements: dict[str, list[float]] = {}
    x = np.arange(truth_hydrology.size, dtype=np.float64)
    plt.figure(figsize=(11.0, 4.8))
    for mode, offset in zip(learned_modes, (-0.17, 0.17)):
        displacement = np.asarray(selected[mode]["hydrology"], dtype=np.float64).reshape(-1) - truth_hydrology
        hydrology_displacements[mode] = displacement.tolist()
        plt.bar(x + offset, displacement, width=0.32, color=MODE_COLORS[mode], label=labels[mode])
    plt.axhline(0.0, color="black", linewidth=1.0)
    plt.xticks(x, [str(index + 1) for index in range(truth_hydrology.size)])
    plt.xlabel("Hydrologic parameter coordinate")
    plt.ylabel("Selected normalized coordinate minus truth")
    plt.legend(frameon=False)
    _save_figure(hydrology_path)
    files.append(hydrology_path)

    filter_path = figure_root / "representative_filter_noise_displacement.png"
    truth_filter = np.concatenate(
        (
            np.asarray(truth_values["truth_process_variances"], dtype=np.float64).reshape(-1),
            np.asarray([truth_values["observation_ratio"]], dtype=np.float64),
        )
    )
    filter_modes = ("filter_only", "joint")
    filter_displacements: dict[str, list[float]] = {}
    x = np.arange(truth_filter.size, dtype=np.float64)
    plt.figure(figsize=(10.0, 4.8))
    for mode, offset in zip(filter_modes, (-0.17, 0.17)):
        chosen = np.concatenate(
            (
                np.asarray(selected[mode]["process_diagonal"], dtype=np.float64).reshape(-1),
                np.asarray(selected[mode]["observation_ratio"], dtype=np.float64).reshape(-1),
            )
        )
        displacement = np.log10(chosen / truth_filter)
        filter_displacements[mode] = displacement.tolist()
        plt.bar(x + offset, displacement, width=0.32, color=MODE_COLORS[mode], label=labels[mode])
    plt.axhline(0.0, color="black", linewidth=1.0)
    plt.xticks(x, [*(f"Q{index + 1}" for index in range(8)), "R"])
    plt.xlabel("Process-noise variance (Q) or observation-noise ratio (R)")
    plt.ylabel("log10(selected / truth)")
    plt.legend(frameon=False)
    _save_figure(filter_path)
    files.append(filter_path)

    manifest = {
        "schema_version": "tukf20_verified_figure_manifest_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": "VERIFIED_FIGURES_COMPLETE",
        "configuration_sha256": common.sha256_file(contract_path),
        "registry_sha256": common.sha256_file(registry_path),
        "independent_verification_sha256": common.sha256_file(verification_path),
        "primary_contrast_order": primary_order,
        "plotted_values": {
            name: {
                "paired_ratios": primary[name]["ratios"],
                "median_ratio": primary[name]["median_ratio"],
                "median_ratio_by_lead": {
                    str(lead): primary[name]["by_lead"][str(lead)]["median_ratio"]
                    for lead in common.LEADS
                },
            }
            for name in primary_order
        },
        "representative_pair": representative,
        "representative_plotted_values": {
            "one_day_issue_days": days.tolist(),
            "clean_targets": np.asarray(
                first["clean_targets"][:, 0], dtype=np.float64
            ).tolist(),
            "noisy_targets": np.asarray(
                first["observed_targets"][:, 0], dtype=np.float64
            ).tolist(),
            "forecasts_by_mode": representative_forecasts,
            "hydrologic_coordinate_displacement_by_mode": hydrology_displacements,
            "filter_log10_selected_over_truth_by_mode": filter_displacements,
        },
        "files": {
            path.name: {
                "bytes": path.stat().st_size,
                "sha256": common.sha256_file(path),
            }
            for path in files
        },
        "technical_verification_is_not_scientific_success": True,
    }
    common.write_new_json(figure_root / "manifest.json", manifest)
    return manifest


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    manifest = generate_figures(
        common.load_contract(contract_path), contract_path=contract_path
    )
    print(json.dumps(manifest, ensure_ascii=False, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
