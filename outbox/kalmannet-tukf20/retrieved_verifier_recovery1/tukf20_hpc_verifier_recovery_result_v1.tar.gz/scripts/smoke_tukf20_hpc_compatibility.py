"""Run the sealed TUKF20 HPC compatibility and balance-preflight gate."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import sys
import time
import traceback
from typing import Any, Mapping

import numpy as np
import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf20_hpc_deployment_common as deployment_common


DEFAULT_CONFIG = deployment_common.DEFAULT_CONFIG


def _member_path(root: Path, name: str) -> Path:
    if not isinstance(name, str) or not name or "\\" in name:
        raise ValueError(f"unsafe payload member in manifest: {name!r}")
    pure = PurePosixPath(name)
    if pure.is_absolute() or ".." in pure.parts:
        raise ValueError(f"unsafe payload member in manifest: {name}")
    candidate = root.joinpath(*pure.parts).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError as error:
        raise ValueError(f"payload member escapes root: {name}") from error
    return candidate


def verify_extracted_payload(
    root: Path, external_manifest_path: Path
) -> dict[str, Any]:
    from scripts import build_tukf20_hpc_bundle as bundle_builder

    external = deployment_common.read_json(external_manifest_path)
    if external.get("schema_version") != "tukf20_hpc_bundle_manifest_v1":
        raise ValueError("unexpected TUKF20 bundle manifest schema")
    if external.get("deployment_id") != deployment_common.DEPLOYMENT_ID:
        raise ValueError("unexpected TUKF20 bundle deployment identity")
    if (
        external.get("scientific_experiment_id")
        != deployment_common.SCIENTIFIC_EXPERIMENT_ID
    ):
        raise ValueError("unexpected TUKF20 bundle scientific identity")
    archive_name = bundle_builder.safe_member_name(external["archive_name"])
    if len(PurePosixPath(archive_name).parts) != 1:
        raise ValueError("transport archive name must be a single file name")
    archive_path = external_manifest_path.parent / archive_name
    if not archive_path.is_file():
        raise FileNotFoundError(f"transport archive is missing: {archive_path}")
    if archive_path.stat().st_size != int(external["archive_bytes"]):
        raise ValueError("transport archive byte count changed")
    if deployment_common.sha256_file(archive_path) != external["archive_sha256"]:
        raise ValueError("transport archive SHA-256 changed")

    bundle_builder.verify_archive_against_manifest(archive_path, external)
    payload_path = _member_path(root, external["payload_manifest_name"])
    if not payload_path.is_file():
        raise FileNotFoundError(f"extracted payload manifest is missing: {payload_path}")
    if deployment_common.sha256_file(payload_path) != external[
        "payload_manifest_sha256"
    ]:
        raise ValueError("extracted payload manifest SHA-256 changed")
    payload = deployment_common.read_json(payload_path)
    if payload.get("schema_version") != "tukf20_hpc_payload_manifest_v1":
        raise ValueError("unexpected TUKF20 payload manifest schema")
    if payload.get("deployment_id") != external.get("deployment_id"):
        raise ValueError("payload and bundle deployment identities differ")
    if payload.get("scientific_experiment_id") != external.get(
        "scientific_experiment_id"
    ):
        raise ValueError("payload and bundle scientific identities differ")
    if payload.get("members") != external.get("members"):
        raise ValueError("payload and external bundle member maps differ")
    if int(external.get("member_count", -1)) != len(payload.get("members", {})):
        raise ValueError("payload and bundle member counts differ")
    if external.get("deployment_config_sha256") is not None and payload.get(
        "deployment_config_sha256"
    ) != external.get("deployment_config_sha256"):
        raise ValueError("payload and bundle deployment configuration hashes differ")
    mismatches: list[str] = []
    seen: set[str] = set()
    for name, expected in payload["members"].items():
        if name in seen:
            raise ValueError(f"duplicate payload member: {name}")
        seen.add(name)
        path = _member_path(root, name)
        if path.is_symlink() or not path.is_file():
            mismatches.append(name)
            continue
        if deployment_common.sha256_file(path) != expected:
            mismatches.append(name)
    if mismatches:
        raise ValueError(f"extracted payload member mismatch: {mismatches}")
    return {
        "bundle_sha256": external["archive_sha256"],
        "bundle_bytes": int(external["archive_bytes"]),
        "deployment_config_sha256": payload.get("deployment_config_sha256"),
        "scientific_source_hashes": payload.get("scientific_source_hashes", {}),
        "payload_manifest_sha256": external["payload_manifest_sha256"],
        "verified_member_count": len(payload["members"]),
    }


def validate_mode_masks(
    masks: Mapping[str, Mapping[str, Any]], *, deployment: Mapping[str, Any]
) -> bool:
    expected = deployment["smoke"]["mode_masks"]
    normalized = {
        str(mode): {
            "hydrology": bool(values.get("hydrology")),
            "filter": bool(values.get("filter")),
            "state_update": bool(values.get("state_update")),
        }
        for mode, values in masks.items()
    }
    if normalized != expected:
        if any(not row["state_update"] for row in normalized.values()):
            raise ValueError("every TUKF20 smoke mode must perform daily state update")
        raise ValueError("TUKF20 smoke mode masks differ from deployment registration")
    return True


def _contract_mode_masks(contract: Mapping[str, Any]) -> dict[str, dict[str, bool]]:
    masks: dict[str, dict[str, bool]] = {}
    for mode in contract["mode_order"]:
        values = contract["mode_masks"][mode]
        updates = contract["mode_state_update"][mode]
        masks[mode] = {
            "hydrology": bool(values["hydrology"]),
            "filter": bool(values["filter"]),
            "state_update": all(
                bool(updates[split]) for split in ("training", "selection", "test")
            ),
        }
    return masks


def _core_modules():
    names = (
        "scripts.tukf20_hbv_rolling_origin_joint_learning_common",
        "scripts.tukf20_hbv_rolling_origin_mode_training",
        "scripts.run_tukf20_hbv_rolling_origin_joint_learning",
        "scripts.verify_tukf20_hbv_rolling_origin_joint_learning",
    )
    modules = []
    for name in names:
        try:
            modules.append(importlib.import_module(name))
        except ModuleNotFoundError as error:
            raise FileNotFoundError(
                f"TUKF20 smoke runtime closure is incomplete: {name}"
            ) from error
    return tuple(modules)


def _truth_equal(left: Any, right: Any) -> bool:
    if isinstance(left, Mapping) and isinstance(right, Mapping):
        return set(left) == set(right) and all(
            _truth_equal(left[key], right[key]) for key in left
        )
    try:
        return bool(np.array_equal(np.asarray(left), np.asarray(right)))
    except (TypeError, ValueError):
        return left == right


def _tensor_inputs(
    contract: Mapping[str, Any], model: Any, forcing: np.ndarray, observations: np.ndarray
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    forcing_tensor = torch.as_tensor(forcing, dtype=model.dtype, device=model.device)
    observation_tensor = torch.as_tensor(
        observations, dtype=model.dtype, device=model.device
    ).reshape(-1)
    initial_state = torch.as_tensor(
        contract["truth_and_filter"]["initial_state"],
        dtype=model.dtype,
        device=model.device,
    )
    covariance = torch.eye(
        int(initial_state.numel()), dtype=model.dtype, device=model.device
    ) * float(contract["truth_and_filter"]["initial_covariance_diagonal"])
    return forcing_tensor, observation_tensor, initial_state, covariance


def _measure_mode(
    scientific: Any,
    mode_training: Any,
    contract: Mapping[str, Any],
    mode: str,
    *,
    start_id: str,
    forcing: np.ndarray,
    observations: np.ndarray,
) -> dict[str, Any]:
    model = scientific.build_model(contract, start_id)
    if model.dtype != torch.float64 or str(model.device) != "cpu":
        raise ValueError("TUKF20 smoke model must use float64 on the CPU")
    mode_training.configure_mode_(model, mode, contract)
    optimizer = mode_training.build_optimizer(model, mode, contract)
    mask = contract["mode_masks"][mode]
    trainable = bool(mask["hydrology"] or mask["filter"])
    if trainable != (optimizer is not None):
        raise RuntimeError(f"TUKF20 smoke optimizer ownership changed: {mode}")
    before = scientific.snapshot_model(model)
    started = time.perf_counter()
    forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
        contract, model, forcing, observations
    )
    if not trainable:
        with torch.no_grad():
            selection_loss, selection_details = scientific.rolling_origin_objective(
                model,
                forcing_tensor,
                observation_tensor,
                initial_state,
                covariance,
                scientific.origin_indices(contract, "selection"),
                state_update=True,
                targets=observation_tensor,
                base_observation_variance=float(
                    contract["truth_and_filter"]["base_observation_variance"]
                ),
            )
        if selection_loss.dtype != torch.float64 or not bool(
            torch.isfinite(selection_loss)
        ):
            raise FloatingPointError("non-finite all-frozen smoke selection loss")
        after = scientific.snapshot_model(model)
        mode_training.assert_frozen_groups_unchanged(before, after, mode, contract)
        return {
            "mode": mode,
            "optimizer_steps": 0,
            "selection_queries": 1,
            "selection_loss": float(selection_loss),
            "selection_mse_by_lead": {
                str(key): float(value)
                for key, value in selection_details["mse_by_lead"].items()
            },
            "gradient_groups": {},
            "initial_snapshot_sha256": mode_training.snapshot_sha256(before),
            "final_snapshot_sha256": mode_training.snapshot_sha256(after),
            "frozen_groups_unchanged": True,
            "state_update_exercised": True,
            "elapsed_seconds": time.perf_counter() - started,
        }
    optimizer.zero_grad(set_to_none=True)
    loss, training_details = scientific.rolling_origin_objective(
        model,
        forcing_tensor,
        observation_tensor,
        initial_state,
        covariance,
        scientific.origin_indices(contract, "train"),
        state_update=True,
        targets=observation_tensor,
        base_observation_variance=float(
            contract["truth_and_filter"]["base_observation_variance"]
        ),
    )
    if loss.dtype != torch.float64 or not bool(torch.isfinite(loss)):
        raise FloatingPointError(f"non-finite or non-float64 smoke loss: {mode}")
    loss.backward()
    gradient_groups = mode_training.clip_active_gradients_(model, mode, contract)
    optimizer.step()
    projector = getattr(model, "project_trainable_coordinates_", None)
    if not callable(projector):
        raise AttributeError("TUKF20 smoke model lacks project_trainable_coordinates_")
    projector()
    after = scientific.snapshot_model(model)
    mode_training.assert_frozen_groups_unchanged(before, after, mode, contract)

    with torch.no_grad():
        selection_loss, selection_details = scientific.rolling_origin_objective(
            model,
            forcing_tensor,
            observation_tensor,
            initial_state,
            covariance,
            scientific.origin_indices(contract, "selection"),
            state_update=True,
            targets=observation_tensor,
            base_observation_variance=float(
                contract["truth_and_filter"]["base_observation_variance"]
            ),
        )
    if selection_loss.dtype != torch.float64 or not bool(torch.isfinite(selection_loss)):
        raise FloatingPointError(f"non-finite smoke selection loss: {mode}")
    return {
        "mode": mode,
        "optimizer_steps": 1,
        "selection_queries": 1,
        "training_loss": float(loss.detach()),
        "selection_loss_after_one_update": float(selection_loss),
        "training_mse_by_lead": {
            str(key): float(value)
            for key, value in training_details["mse_by_lead"].items()
        },
        "selection_mse_by_lead": {
            str(key): float(value)
            for key, value in selection_details["mse_by_lead"].items()
        },
        "gradient_groups": gradient_groups,
        "initial_snapshot_sha256": mode_training.snapshot_sha256(before),
        "final_snapshot_sha256": mode_training.snapshot_sha256(after),
        "frozen_groups_unchanged": True,
        "state_update_exercised": True,
        "elapsed_seconds": time.perf_counter() - started,
    }


def run_numeric_smoke(
    deployment: Mapping[str, Any], contract: Mapping[str, Any]
) -> dict[str, Any]:
    scientific, mode_training, _, _ = _core_modules()
    torch.set_default_dtype(torch.float64)
    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        if torch.get_num_interop_threads() != 1:
            raise
    validate_mode_masks(_contract_mode_masks(contract), deployment=deployment)

    seed = int(deployment["smoke"]["truth_seed"])
    start_id = str(deployment["smoke"]["start_id"])
    forcing, truth = scientific.generate_truth_for_seed(contract, seed)
    repeated_forcing, repeated_truth = scientific.generate_truth_for_seed(contract, seed)
    truth_deterministic = bool(
        np.array_equal(np.asarray(forcing), np.asarray(repeated_forcing))
        and _truth_equal(truth, repeated_truth)
    )
    observations = np.asarray(truth["observations"], dtype=np.float64)
    rows = {
        mode: _measure_mode(
            scientific,
            mode_training,
            contract,
            mode,
            start_id=start_id,
            forcing=np.asarray(forcing, dtype=np.float64),
            observations=observations,
        )
        for mode in deployment["smoke"]["modes"]
    }
    first_pass_elapsed = sum(
        float(rows[mode]["elapsed_seconds"])
        for mode in deployment["smoke"]["active_modes"]
    )
    return {
        "truth_seed": seed,
        "start_id": start_id,
        "truth_generation_deterministic": truth_deterministic,
        "modes": rows,
        "active_mode_optimizer_steps": {
            mode: int(rows[mode]["optimizer_steps"])
            for mode in deployment["smoke"]["active_modes"]
        },
        "test_origin_queries": 0,
        "clean_target_queries": 0,
        "first_pass_elapsed_seconds": first_pass_elapsed,
        "projected_formal_seconds": first_pass_elapsed
        * float(deployment["smoke"]["formal_runtime_projection_multiplier"]),
    }


def run_balance_preflight(contract: Mapping[str, Any]) -> dict[str, Any]:
    scientific, _, scientific_runner, scientific_verifier = _core_modules()
    contract_path = Path(scientific.DEFAULT_CONFIG).resolve()
    preflight = scientific_runner.run_preflight(
        contract, contract_path=contract_path
    )
    verification = scientific_verifier.verify_preflight(
        contract, contract_path=contract_path
    )
    return {"preflight": preflight, "verification": verification}


def _environment_report() -> dict[str, Any]:
    import matplotlib

    return {
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "torch": torch.__version__,
        "psutil": psutil.__version__,
        "matplotlib": matplotlib.__version__,
        "torch_default_dtype": str(torch.get_default_dtype()),
        "torch_threads": torch.get_num_threads(),
        "torch_interop_threads": torch.get_num_interop_threads(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "slurm_partition": os.environ.get("SLURM_JOB_PARTITION"),
        "slurm_cpus_per_task": os.environ.get("SLURM_CPUS_PER_TASK"),
        "node": os.environ.get("SLURMD_NODENAME") or platform.node(),
        "thread_environment": {
            name: os.environ.get(name)
            for name in deployment_common.EXPECTED_SLURM["thread_environment"]
        },
    }


def run_smoke(
    *,
    deployment_path: Path = DEFAULT_CONFIG,
    external_manifest_path: Path | None = None,
) -> dict[str, Any]:
    started = time.perf_counter()
    deployment = deployment_common.load_deployment(
        deployment_path, validate_sources=True
    )
    report_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["smoke_report"]
    )
    if report_path.exists():
        raise FileExistsError(f"refusing to replace HPC smoke report: {report_path}")
    manifest_path = external_manifest_path or (
        ROOT / "_transport" / deployment["outputs"]["bundle_manifest_name"]
    )
    base_report: dict[str, Any] = {
        "schema_version": "tukf20_hpc_smoke_report_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "deployment_config_sha256": deployment_common.sha256_file(deployment_path),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
    }
    try:
        slurm_job_id = deployment_common.require_slurm_allocation(
            os.environ, deployment
        )
        package = verify_extracted_payload(ROOT, manifest_path)
        scientific, _, _, _ = _core_modules()
        contract = scientific.load_contract(scientific.DEFAULT_CONFIG)
        source_hashes = scientific.source_hashes(contract, scientific.DEFAULT_CONFIG)
        numeric = run_numeric_smoke(deployment, contract)
        balance = run_balance_preflight(contract)
        environment = _environment_report()
        memory_gib = float(psutil.virtual_memory().available / (1024**3))
        storage_gib = float(shutil.disk_usage(ROOT).free / (1024**3))
        rss_gib = float(psutil.Process().memory_info().rss / (1024**3))
        elapsed = time.perf_counter() - started
        active_steps = numeric["active_mode_optimizer_steps"]
        mode_rows = numeric["modes"]
        checks = {
            "payload_integrity": package["verified_member_count"] > 0,
            "deployment_configuration_binding": package[
                "deployment_config_sha256"
            ]
            == base_report["deployment_config_sha256"],
            "scientific_source_hashes": package["scientific_source_hashes"]
            == source_hashes,
            "scientific_contract": contract["experiment_id"]
            == deployment["scientific_experiment_id"],
            "environment_imports": all(
                environment[name]
                for name in ("numpy", "torch", "psutil", "matplotlib")
            ),
            "float64": environment["torch_default_dtype"] == "torch.float64"
            and contract["numerical_environment"]["torch_dtype"] == "float64"
            and contract["numerical_environment"]["numpy_dtype"] == "float64",
            "single_torch_thread": int(environment["torch_threads"]) == 1,
            "thread_environment": environment["thread_environment"]
            == deployment["slurm"]["thread_environment"],
            "slurm_allocation": int(environment["slurm_job_id"]) == slurm_job_id
            and environment["slurm_partition"] == deployment["slurm"]["partition"]
            and str(environment["slurm_cpus_per_task"])
            == str(deployment["slurm"]["cpus_per_task"]),
            "mode_masks": validate_mode_masks(
                _contract_mode_masks(contract), deployment=deployment
            ),
            "truth_generation_deterministic": bool(
                numeric["truth_generation_deterministic"]
            ),
            "one_step_per_active_mode": active_steps
            == {mode: 1 for mode in deployment["smoke"]["active_modes"]},
            "frozen_group_invariance": all(
                bool(row["frozen_groups_unchanged"])
                for row in mode_rows.values()
            ),
            "all_four_modes_exercised_state_update": all(
                bool(row["state_update_exercised"]) for row in mode_rows.values()
            ),
            "balance_gate": balance["preflight"].get("status")
            == "PREFLIGHT_ENGINEERING_PASS"
            and balance["preflight"].get("balance_status") == "BALANCE_PASS",
            "independent_preflight": balance["verification"].get("status")
            == "PREFLIGHT_VERIFIED"
            and bool(balance["verification"].get("checks"))
            and all(balance["verification"]["checks"].values()),
            "sealed_test_boundary": int(numeric["test_origin_queries"]) == 0
            and int(numeric["clean_target_queries"]) == 0
            and int(balance["preflight"].get("test_metric_queries", -1)) == 0
            and int(balance["preflight"].get("clean_test_target_queries", -1))
            == 0
            and int(balance["preflight"].get("formal_optimizer_updates", -1)) == 0,
            "available_memory": memory_gib
            >= float(deployment["smoke"]["minimum_available_memory_gib"]),
            "free_storage": storage_gib
            >= float(deployment["smoke"]["minimum_free_storage_gib"]),
            "finite_resident_memory": math.isfinite(rss_gib) and rss_gib > 0.0,
            "smoke_runtime": elapsed
            <= float(deployment["smoke"]["maximum_smoke_elapsed_seconds"]),
            "formal_runtime_projection": float(numeric["projected_formal_seconds"])
            <= float(deployment["smoke"]["maximum_projected_formal_seconds"]),
            "formal_result_absent": not scientific.resolve_output_path(
                contract, contract["outputs"]["result_root"]
            ).exists(),
            "formal_figure_absent": not scientific.resolve_output_path(
                contract, contract["outputs"]["figure_root"]
            ).exists(),
        }
        report = {
            **base_report,
            "status": "HPC_SMOKE_PASS" if all(checks.values()) else "HPC_SMOKE_FAIL",
            "checks": checks,
            "bundle_sha256": package["bundle_sha256"],
            "package": package,
            "environment": environment,
            "resources": {
                "available_memory_gib": memory_gib,
                "free_storage_gib": storage_gib,
                "resident_memory_gib": rss_gib,
            },
            "numeric": numeric,
            "balance_preflight": balance,
            "elapsed_seconds": elapsed,
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        }
    except BaseException as error:
        report = {
            **base_report,
            "status": "HPC_SMOKE_ERROR",
            "checks": {"completed_without_exception": False},
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "elapsed_seconds": time.perf_counter() - started,
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        }
    deployment_common.write_new_json(report_path, report)
    return report


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--bundle-manifest", type=Path)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    report = run_smoke(
        deployment_path=args.config.resolve(),
        external_manifest_path=(
            args.bundle_manifest.resolve() if args.bundle_manifest else None
        ),
    )
    print(
        json.dumps(
            {"status": report["status"], "checks": report["checks"]},
            sort_keys=True,
        )
    )
    return 0 if report["status"] == "HPC_SMOKE_PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
