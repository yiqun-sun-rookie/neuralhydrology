"""Frozen deployment-only contract for the TUKF20 Linux migration.

The module validates transport, authorization, scheduler, path, and exact-once
submission rules.  It never runs the scientific experiment.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping
import hashlib
import importlib
import json
from pathlib import Path
import re
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "tukf20_hpc_deployment_v1.json"
DEPLOYMENT_ID = "TUKF20_HBV_ROLLING_ORIGIN_JOINT_LEARNING_HPC_DEPLOYMENT_V1"
SCIENTIFIC_EXPERIMENT_ID = "TUKF20_HBV_ROLLING_ORIGIN_JOINT_LEARNING_V1"

EXPECTED_AUTHORIZATION = {
    "implementation_authorized": True,
    "paid_smoke_job_authorized": True,
    "formal_after_smoke_authorized": True,
    "two_hour_monitoring_authorized": True,
    "recoverable_in_scope_repairs_authorized_without_reconfirmation": True,
    "scientific_contract_change_forbidden": True,
    "implementation_worktree_commit_forbidden": True,
    "mailbox_transport_commits_authorized": True,
    "publication_forbidden": True,
    "cleanup_forbidden": True,
    "authorization_date": "2026-08-24",
}
EXPECTED_SOURCE_CONTRACT = {
    "scientific_config_path": (
        "configs/tukf20_hbv_rolling_origin_joint_learning_v1.json"
    ),
    "implementation_plan_path": (
        "docs/superpowers/plans/2026-08-24-tukf20-rolling-origin-joint-learning.md"
    ),
    "implementation_plan_sha256": (
        "850682bc069ab2b2dba1ec351b9bb0d20ff7f82cf9e8136749762463f52afff8"
    ),
    "scientific_hash_registry_required": True,
    "deployment_config_bound_by_payload_manifest": True,
    "readonly_kalmannet_root": "G:/github/pycharm/projects/kalmannet",
    "readonly_neuralhydrology_root": "G:/github/pycharm/projects/neuralhydrology",
    "external_numpy_hbv_path": (
        "G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/hbv_lite_numpy.py"
    ),
    "external_numpy_hbv_sha256": (
        "8c6356926fd6b4bdef672c4ea56bc7941291ee05298dd461100e919beb590103"
    ),
}
EXPECTED_HPC = {
    "mailbox_channel": "kalmannet-tukf20",
    "target_root": "/data1/home/sunyiq/kalmannet_tukf20_20260824",
    "conda_environment": "nh_final",
    "runner": "runner2.sh",
    "monitor_interval_hours": 2,
    "target_must_be_absent": True,
    "retry_requires_new_target": True,
    "atomic_staging_deployment_required": True,
    "original_hpc_repository_must_remain_untouched": True,
}
EXPECTED_SLURM = {
    "partition": "hcpu48y",
    "nodes": 1,
    "ntasks": 1,
    "cpus_per_task": 1,
    "smoke_time_limit": "00:30:00",
    "formal_time_limit": "1-00:00:00",
    "custom_memory_directive_forbidden": True,
    "srun_forbidden": True,
    "set_u_forbidden": True,
    "thread_environment": {
        "MKL_THREADING_LAYER": "GNU",
        "MKL_SERVICE_FORCE_INTEL": "1",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
    },
}
EXPECTED_MODE_MASKS = {
    "all_frozen": {"hydrology": False, "filter": False, "state_update": True},
    "hydrology_only": {
        "hydrology": True,
        "filter": False,
        "state_update": True,
    },
    "filter_only": {
        "hydrology": False,
        "filter": True,
        "state_update": True,
    },
    "joint": {"hydrology": True, "filter": True, "state_update": True},
}
EXPECTED_SMOKE = {
    "truth_seed": 1901,
    "start_id": "start_03",
    "modes": ["all_frozen", "hydrology_only", "filter_only", "joint"],
    "active_modes": ["hydrology_only", "filter_only", "joint"],
    "mode_masks": EXPECTED_MODE_MASKS,
    "optimizer_updates_per_active_mode": 1,
    "dtype": "float64",
    "torch_threads": 1,
    "test_origin_queries": 0,
    "clean_target_queries": 0,
    "minimum_available_memory_gib": 8.0,
    "minimum_free_storage_gib": 2.0,
    "maximum_smoke_elapsed_seconds": 1500.0,
    "formal_runtime_projection_multiplier": 3000.0,
    "maximum_projected_formal_seconds": 72000.0,
}
EXPECTED_SUBMISSION_GUARD = {
    "literal_success_record": "Submitted batch job",
    "raw_output_must_precede_parsing": True,
    "receipt_required": True,
    "stored_job_identifier_required": True,
    "squeue_check_required": True,
    "sacct_check_required": True,
    "duplicate_submission_forbidden": True,
}
EXPECTED_OUTPUTS = {
    "local_bundle_root": "artifacts/tukf20_hpc_deployment_v1",
    "bundle_name": "tukf20_hpc_payload_v1.tar.gz",
    "bundle_manifest_name": "bundle_manifest.sha256.json",
    "payload_manifest_name": "payload_manifest.json",
    "smoke_report": (
        "artifacts/tukf20_hpc_deployment_v1/smoke/smoke_report.json"
    ),
    "hpc_status_root": "artifacts/tukf20_hpc_deployment_v1/status",
    "smoke_completion_record": (
        "artifacts/tukf20_hpc_deployment_v1/status/smoke_completion.json"
    ),
    "formal_completion_record": (
        "artifacts/tukf20_hpc_deployment_v1/status/formal_completion.json"
    ),
    "formal_result_archive": (
        "artifacts/tukf20_hpc_deployment_v1/tukf20_hpc_formal_result_v1.tar.gz"
    ),
    "formal_result_payload_manifest_name": "formal_result_payload_manifest.json",
}
EXPECTED_FORMAL_EXPECTATIONS = {
    "mode_history_count": 108,
    "test_readout_count": 108,
    "primary_clean_error_count": 13608,
    "primary_contrasts": [
        "joint_over_all_frozen",
        "joint_over_hydrology_only",
        "joint_over_filter_only",
    ],
    "registry_status": "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION",
    "independent_verification_status": "FORMAL_VERIFIED",
    "figure_manifest_status": "VERIFIED_FIGURES_COMPLETE",
}
EXPECTED_CLAIMS_NOT_AUTHORIZED = [
    "scientific success from deployment success",
    "scientific success from smoke success",
    "scientific success from technical verification alone",
    "joint-learning advantage unless all three primary contrasts pass",
    "parameter identification or recovery of uniquely true parameters",
    "real-catchment validity",
    "robustness to forcing forecast error",
    "test-period online parameter learning",
]


def read_json(path: Path | str) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise TypeError(f"expected a JSON object: {path}")
    return payload


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def write_new_json(path: Path | str, payload: Mapping[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as handle:
        handle.write(canonical_json_bytes(payload))


def resolve_root_relative(raw: Path | str) -> Path:
    value = Path(str(raw))
    if value.is_absolute():
        raise ValueError("deployment output must be root-relative")
    candidate = (ROOT / value).resolve()
    try:
        candidate.relative_to(ROOT.resolve())
    except ValueError as error:
        raise ValueError(f"deployment path escapes payload root: {candidate}") from error
    return candidate


def _validate_scientific_sources(deployment: Mapping[str, Any]) -> dict[str, str]:
    source = deployment["source_contract"]
    scientific_config = resolve_root_relative(source["scientific_config_path"])
    if not scientific_config.is_file():
        raise FileNotFoundError(
            "TUKF20 scientific configuration is not yet available: "
            f"{scientific_config}"
        )
    plan_path = resolve_root_relative(source["implementation_plan_path"])
    if sha256_file(plan_path) != source["implementation_plan_sha256"]:
        raise ValueError("frozen TUKF20 implementation plan hash changed")

    try:
        scientific = importlib.import_module(
            "scripts.tukf20_hbv_rolling_origin_joint_learning_common"
        )
    except ModuleNotFoundError as error:
        raise FileNotFoundError(
            "TUKF20 scientific common module is not yet available"
        ) from error
    load_contract = getattr(scientific, "load_contract", None)
    source_hashes = getattr(scientific, "source_hashes", None)
    if not callable(load_contract) or not callable(source_hashes):
        raise AttributeError(
            "TUKF20 scientific common must expose load_contract and source_hashes"
        )
    contract = load_contract(scientific_config)
    if contract.get("experiment_id") != SCIENTIFIC_EXPERIMENT_ID:
        raise ValueError("loaded TUKF20 scientific experiment identity changed")
    hashes = source_hashes(contract, scientific_config)
    if not isinstance(hashes, Mapping) or not hashes:
        raise ValueError("TUKF20 scientific source hash registry is empty")
    if not all(
        isinstance(name, str)
        and isinstance(value, str)
        and re.fullmatch(r"[0-9a-f]{64}", value)
        for name, value in hashes.items()
    ):
        raise ValueError("TUKF20 scientific source hash registry is malformed")
    return dict(hashes)


def validate_deployment(
    deployment: Mapping[str, Any],
    *,
    configuration_path: Path | str = DEFAULT_CONFIG,
    validate_sources: bool = True,
) -> dict[str, Any]:
    if deployment.get("schema_version") != "tukf20_hpc_deployment_v1":
        raise ValueError("unexpected TUKF20 HPC deployment schema")
    if deployment.get("deployment_id") != DEPLOYMENT_ID:
        raise ValueError("unexpected TUKF20 HPC deployment identifier")
    if deployment.get("scientific_experiment_id") != SCIENTIFIC_EXPERIMENT_ID:
        raise ValueError("scientific experiment identity changed during deployment")
    if deployment.get("status") != "HPC_MIGRATION_AND_GATED_PAID_EXECUTION_AUTHORIZED":
        raise PermissionError("TUKF20 HPC deployment authorization status changed")
    exact_sections = {
        "authorization": EXPECTED_AUTHORIZATION,
        "source_contract": EXPECTED_SOURCE_CONTRACT,
        "hpc": EXPECTED_HPC,
        "slurm": EXPECTED_SLURM,
        "smoke": EXPECTED_SMOKE,
        "submission_guard": EXPECTED_SUBMISSION_GUARD,
        "outputs": EXPECTED_OUTPUTS,
        "formal_expectations": EXPECTED_FORMAL_EXPECTATIONS,
        "claims_not_authorized": EXPECTED_CLAIMS_NOT_AUTHORIZED,
    }
    for section, expected in exact_sections.items():
        if deployment.get(section) != expected:
            error = PermissionError if section == "authorization" else ValueError
            raise error(f"TUKF20 HPC deployment contract changed: {section}")

    configuration = Path(configuration_path)
    if configuration.resolve() != DEFAULT_CONFIG.resolve():
        if not configuration.is_file():
            raise FileNotFoundError(configuration)
        if read_json(configuration) != dict(deployment):
            raise ValueError("validated deployment does not match configuration file")
    source_hashes: dict[str, str] = {}
    if validate_sources:
        source_hashes = _validate_scientific_sources(deployment)
    return {
        "authorization_verified": True,
        "scientific_identity_verified": True,
        "scheduler_contract_verified": True,
        "source_hashes": source_hashes,
    }


def load_deployment(
    path: Path | str = DEFAULT_CONFIG, *, validate_sources: bool = True
) -> dict[str, Any]:
    deployment = read_json(path)
    validate_deployment(
        deployment,
        configuration_path=path,
        validate_sources=validate_sources,
    )
    return deployment


_SUBMITTED_JOB_PATTERN = re.compile(r"(?:^|\n)Submitted batch job ([0-9]+)(?:\n|$)")


def parse_submitted_job_id(raw_output: str) -> int:
    matches = _SUBMITTED_JOB_PATTERN.findall(str(raw_output))
    if len(matches) != 1:
        raise ValueError(
            "submission success requires one literal Submitted batch job record"
        )
    job_id = int(matches[0])
    if job_id <= 0:
        raise ValueError("submitted Slurm job identifier must be positive")
    return job_id


def submission_evidence_paths(root: Path | str, *, stage: str) -> dict[str, Path]:
    if stage not in {"smoke", "formal"}:
        raise ValueError(f"unknown submission stage: {stage}")
    status_root = Path(root)
    return {
        "raw_output": status_root / f"{stage}_submission_raw.txt",
        "receipt": status_root / f"{stage}_submission_receipt.json",
        "job_id": status_root / f"{stage}_job_id.txt",
        "squeue": status_root / f"{stage}_squeue_snapshot.txt",
        "sacct": status_root / f"{stage}_sacct_snapshot.txt",
    }


def assert_submission_absent(
    evidence_paths: Mapping[str, Path | str],
    *,
    queued_job_ids: Iterable[int | str],
    accounted_job_ids: Iterable[int | str],
) -> None:
    present = [str(path) for path in evidence_paths.values() if Path(path).exists()]
    queued = [str(value) for value in queued_job_ids]
    accounted = [str(value) for value in accounted_job_ids]
    if present or queued or accounted:
        raise FileExistsError(
            "refusing duplicate submission because submission evidence exists: "
            f"files={present}, squeue={queued}, sacct={accounted}"
        )


def validate_submission_receipt(
    receipt: Mapping[str, Any], raw_output: str, *, stage: str
) -> int:
    parsed = parse_submitted_job_id(raw_output)
    if receipt.get("stage") != stage:
        raise ValueError("submission receipt stage differs")
    if int(receipt.get("job_id", -1)) != parsed:
        raise ValueError("submission receipt job identifier differs from raw output")
    if receipt.get("raw_output_sha256") != sha256_bytes(raw_output.encode("utf-8")):
        raise ValueError("submission receipt raw-output hash differs")
    return parsed


def require_slurm_allocation(
    environment: Mapping[str, Any], deployment: Mapping[str, Any]
) -> int:
    job_id = str(environment.get("SLURM_JOB_ID") or "")
    if not job_id.isdigit() or int(job_id) <= 0:
        raise PermissionError("TUKF20 paid execution requires a positive Slurm job identifier")
    if str(environment.get("SLURM_JOB_PARTITION") or "") != str(
        deployment["slurm"]["partition"]
    ):
        raise PermissionError("TUKF20 Slurm partition differs from the frozen contract")
    if str(environment.get("SLURM_CPUS_PER_TASK") or "") != str(
        deployment["slurm"]["cpus_per_task"]
    ):
        raise PermissionError("TUKF20 Slurm CPU allocation differs from the frozen contract")
    return int(job_id)


def validate_completed_sacct(
    raw_text: str,
    *,
    job_id: int,
    deployment: Mapping[str, Any],
) -> dict[str, str]:
    matches: list[list[str]] = []
    for line in str(raw_text).splitlines():
        fields = line.rstrip("|").split("|")
        if len(fields) >= 6 and fields[0] == str(job_id):
            matches.append(fields)
    if len(matches) != 1:
        raise ValueError("Slurm accounting must contain exactly one main job row")
    fields = matches[0]
    row = {
        "job_id": fields[0],
        "job_name": fields[1],
        "partition": fields[2],
        "allocated_cpus": fields[3],
        "state": fields[4],
        "exit_code": fields[5],
    }
    if row["partition"] != str(deployment["slurm"]["partition"]):
        raise ValueError("Slurm accounting partition differs from the frozen contract")
    if row["allocated_cpus"] != str(deployment["slurm"]["cpus_per_task"]):
        raise ValueError("Slurm accounting CPU count differs from the frozen contract")
    if row["state"] != "COMPLETED" or row["exit_code"] != "0:0":
        raise ValueError("Slurm accounting is not COMPLETED with exit code 0:0")
    return row
