"""Frozen contract and shared primitives for TUKF20 joint learning.

All four modes use the same rolling state-update computation.  The modes differ
only in ownership of the hydrologic and filter-noise parameter groups.  This
module delegates already audited numerical kernels to hash-locked predecessor
sources and owns the new contract, seed registry, pairing, and decision rules.
Importing it performs no experiment and creates no file.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from fractions import Fraction
import math
from pathlib import Path
from typing import Any

import numpy as np

from scripts import tukf17_hbv_rolling_origin_state_hydrology_common as base
from scripts import tukf18_hbv_rolling_origin_balance_common as balance


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = (
    ROOT / "configs" / "tukf20_hbv_rolling_origin_joint_learning_v1.json"
)
EXPERIMENT_ID = "TUKF20_HBV_ROLLING_ORIGIN_JOINT_LEARNING_V1"
SCHEMA_VERSION = "tukf20_hbv_rolling_origin_joint_learning_v1"

MODE_ORDER = (
    "all_frozen",
    "hydrology_only",
    "filter_only",
    "joint",
)
PIPELINE_ORDER = MODE_ORDER
READOUT_ORDER = PIPELINE_ORDER
LEADS = (1, 2, 3)
ORIGIN_WINDOWS = base.ORIGIN_WINDOWS
START_IDS = base.START_IDS
STATE_SCALES = base.STATE_SCALES
PROCESS_NOISE_BOUNDS = base.PROCESS_NOISE_BOUNDS
OBSERVATION_RATIO_BOUNDS = base.OBSERVATION_RATIO_BOUNDS

EXPECTED_AUTHORIZATION = {
    "implementation_authorized": True,
    "gated_hpc_smoke_authorized": True,
    "single_formal_paid_job_after_smoke_authorized": True,
    "formal_submission_requires_passing_smoke": True,
    "authorization_date": "2026-08-24",
    "basis": (
        "The user explicitly agreed to the proposed four-mode state-update "
        "joint-learning experiment and requested omission of work without "
        "final-goal value."
    ),
}
EXPECTED_PARENT_CONFIGS = {
    "truth_generator": (
        "configs/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1.json"
    ),
    "start_registry": (
        "configs/tukf14_hbv_four_mode_randomised_start_ablation_v1.json"
    ),
}
EXPECTED_DELEGATED_SOURCES = {
    "four_mode_common": {
        "scope": "readonly_predecessor",
        "path": "scripts/tukf16_hbv_balanced_error_four_mode_common.py",
        "sha256": (
            "bc0397940c7b8f87ddcd50dd40cf9136568306fe80903f69be368cdf51b0ff72"
        ),
    },
    "rolling_origin_common": {
        "scope": "isolated_worktree",
        "path": "scripts/tukf17_hbv_rolling_origin_state_hydrology_common.py",
        "sha256": (
            "f72d5d593d5c5d69525693530ab89e5632a5ba4f0975a0107c91abd26c14302e"
        ),
    },
    "balanced_start_common": {
        "scope": "isolated_worktree",
        "path": "scripts/tukf18_hbv_rolling_origin_balance_common.py",
        "sha256": (
            "f69a03886ce2ac69040bb99f8275e3d5ed532a90390f7ff418b79e728333a0ca"
        ),
    },
}
EXPECTED_MODE_MASKS = {
    "all_frozen": {"hydrology": False, "filter": False},
    "hydrology_only": {"hydrology": True, "filter": False},
    "filter_only": {"hydrology": False, "filter": True},
    "joint": {"hydrology": True, "filter": True},
}
EXPECTED_MODE_STATE_UPDATE = {
    mode: {"training": True, "selection": True, "test": True}
    for mode in PIPELINE_ORDER
}
EXPECTED_DISPLAY_LABELS = {
    "modes": {
        "all_frozen": "State Updating with All Parameters Frozen",
        "hydrology_only": "State Updating with Hydrologic Parameters Learned",
        "filter_only": "State Updating with Filter-Noise Parameters Learned",
        "joint": (
            "State Updating with Hydrologic and Filter-Noise Parameters "
            "Jointly Learned"
        ),
    },
    "primary_contrasts": {
        "joint_over_all_frozen": "Joint Learning versus All Parameters Frozen",
        "joint_over_hydrology_only": (
            "Joint Learning versus Hydrologic-Parameter Learning Only"
        ),
        "joint_over_filter_only": (
            "Joint Learning versus Filter-Noise-Parameter Learning Only"
        ),
    },
}
EXPECTED_READOUT_GRID = {
    mode: {
        "parameter_source_pipeline": mode,
        "parameter_set": f"{mode}_selected_parameters",
        "state_update": True,
        "primary_pipeline": True,
    }
    for mode in PIPELINE_ORDER
}
EXPECTED_PRIMARY_CONTRASTS = {
    "joint_over_all_frozen": {
        "numerator": "joint",
        "denominator": "all_frozen",
    },
    "joint_over_hydrology_only": {
        "numerator": "joint",
        "denominator": "hydrology_only",
    },
    "joint_over_filter_only": {
        "numerator": "joint",
        "denominator": "filter_only",
    },
}
EXPECTED_SECONDARY_CONTRASTS = {
    "hydrology_only_over_all_frozen": {
        "numerator": "hydrology_only",
        "denominator": "all_frozen",
    },
    "filter_only_over_all_frozen": {
        "numerator": "filter_only",
        "denominator": "all_frozen",
    },
}
EXPECTED_INTERACTION = {
    "formula": "joint_times_all_frozen_over_hydrology_only_times_filter_only",
    "descriptive_only": True,
    "causal_or_success_gate": False,
}
EXPECTED_BALANCED_DESIGN = {
    "process_standard_deviation_fraction": 0.02,
    "filter_perturbation_factor": 8.0,
    "filter_perturbation_low_multiplier": 0.125,
    "filter_perturbation_high_multiplier": 8.0,
    "hydrology_coordinate_distance": 0.05,
    "influence_ratio_interval": [1.0 / 3.0, 3.0],
}
EXPECTED_SEED_POLICY = {
    "first_candidate": 1901,
    "candidate_step": 1,
    "accepted_count": 27,
    "start_ids_in_accepted_order": list(START_IDS),
    "prior_attempted_seed_intervals": {
        "tukf17": [1701, 1730],
        "tukf18": [1801, 1832],
    },
    "acceptance_conditions": {
        "all_truth_arrays_finite": True,
        "maximum_projection_fraction": 0.15,
        "maximum_observation_fixed_point_error": 1e-12,
        "minimum_proportional_observation_branch_fraction": 0.5,
    },
}
EXPECTED_TRUTH_AND_FILTER = {
    "days": 192,
    "initial_state": [8.0, 1.0, 180.0, 25.0, 50.0, 0.0, 0.0, 0.0],
    "state_scales": [8.0, 1.0, 180.0, 25.0, 50.0, 1.0, 1.0, 1.0],
    "initial_covariance_diagonal": 0.001,
    "base_observation_variance": 0.0001,
    "fixed_lag_time_days": 3.0,
    "process_noise_bounds": [1e-6, 200.0],
    "observation_ratio_bounds": [0.0025, 0.8],
}
EXPECTED_ORIGINS = {
    "train": {"start": 27, "end_inclusive": 104, "count": 78},
    "selection": {"start": 107, "end_inclusive": 144, "count": 38},
    "test": {"start": 147, "end_inclusive": 188, "count": 42},
}
EXPECTED_OBJECTIVE = {
    "leads_days": [1, 2, 3],
    "lead_weights": [1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0],
    "shared_origins_for_all_leads": True,
    "training_and_selection_target": "noisy_discharge_observation",
    "primary_test_target": "clean_discharge",
    "secondary_test_target": "noisy_discharge_observation",
    "future_observation_updates_forbidden": True,
    "future_forcing": "perfect_synthetic_forcing",
    "origin_state_alignment": (
        "state_after_processing_origin_day_equals_truth_states_origin_plus_one"
    ),
}
EXPECTED_OPTIMIZER = {
    "name": "Adam",
    "hydrology_learning_rate": 0.005,
    "filter_learning_rate": 0.05,
    "group_gradient_norm": 1.0,
    "updates": 96,
    "selection_interval": 4,
    "betas": [0.9, 0.999],
    "epsilon": 1e-8,
    "weight_decay": 0.0,
    "amsgrad": False,
}
EXPECTED_SELECTION = {
    "query_updates": list(range(0, 97, 4)),
    "metric": "selection_origin_equal_weight_noisy_observation_mse",
    "direction": "minimize",
    "tie_break": "earliest_update",
    "nonlearning_selected_update": 0,
}
EXPECTED_BUDGET = {
    "mode_cells": 108,
    "trainable_mode_cells": 81,
    "real_optimizer_updates": 7776,
    "selection_queries": 2052,
    "selected_checkpoints": 108,
    "test_readout_units": 108,
    "state_updating_test_readout_units": 108,
    "primary_errors_per_readout_unit": 126,
    "total_primary_clean_errors": 13608,
    "clean_target_queries_before_global_selection_seal": 0,
    "test_observation_inputs_before_global_selection_seal": 0,
}
EXPECTED_GATES = {
    "clear_benefit_median_ratio_maximum": 0.9,
    "clear_harm_median_ratio_minimum": 1.1,
    "minimum_paired_improvements": 19,
    "minimum_direction_count": 19,
    "independent_replicates": 27,
    "sign_test_one_sided_alpha": 0.05,
    "classes": [
        "CLEAR_BENEFIT",
        "CLEAR_HARM",
        "DIRECTIONAL_SMALL",
        "MIXED_OR_INCONCLUSIVE",
    ],
}
EXPECTED_SCIENTIFIC_DECISION = {
    "success_requires_all_primary_clear_benefit": True,
    "success_label": "FINAL_JOINT_ADVANTAGE_ESTABLISHED",
    "failure_label": "FINAL_JOINT_ADVANTAGE_NOT_ESTABLISHED",
    "failure_stops_scientific_retuning": True,
}
EXPECTED_BALANCE_PREFLIGHT = {
    "influence_ratio_interval": [1.0 / 3.0, 3.0],
    "required_windows": ["train", "selection"],
    "required_leads_days": [1, 2, 3],
    "equal_weight_summary_required": True,
    "required_ratio_count": 8,
    "test_metric_queries": 0,
    "failure_stops_formal_execution": True,
    "replacement_setting_forbidden": True,
}
EXPECTED_RESOURCES = {
    "minimum_available_memory_gib": 8.0,
    "minimum_workspace_free_storage_gib": 2.0,
    "maximum_same_experiment_other_controllers": 0,
    "unrelated_formal_processes_allowed": True,
}
EXPECTED_NUMERICAL_ENVIRONMENT = {
    "device": "cpu",
    "torch_dtype": "float64",
    "numpy_dtype": "float64",
    "torch_threads": 1,
}
EXPECTED_OUTPUTS = {
    "preflight_root": (
        "artifacts/tukf20_hbv_rolling_origin_joint_learning_v1/preflight"
    ),
    "result_root": "results/tukf20_hbv_rolling_origin_joint_learning_v1",
    "failed_result_root": (
        "results/tukf20_hbv_rolling_origin_joint_learning_v1_failed_attempts"
    ),
    "figure_root": (
        "artifacts/tukf20_hbv_rolling_origin_joint_learning_v1/"
        "formal_verified_summary_v1"
    ),
    "hpc_retrieved_root": (
        "artifacts/tukf20_hbv_rolling_origin_joint_learning_v1/hpc_retrieved"
    ),
}
EXPECTED_READONLY_INPUT_SHA256 = {
    "configs/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1.json": (
        "3f370beee3f41b217e0820c46faf2879c69b3f5c267841c9efafbc356c148244"
    ),
    "configs/tukf14_hbv_four_mode_randomised_start_ablation_v1.json": (
        "e2bbf367bffd8c045f9b638cfde0552f4b7da5dee05239b7f19a89ae3c8605fe"
    ),
    "configs/tukf16_hbv_balanced_error_four_mode_rerun_v1.json": (
        "a23edf29a6e297765ad079f31a8615289a01ec350c442f59ba0c6b265c1ac1b6"
    ),
    "scripts/tukf11_hbv_joint_parameter_synthetic_common.py": (
        "1248d59e385f3d9f285ac80941a7541a020e74a80b6c495acd8c6a33be67b6d8"
    ),
    "scripts/run_tukf11_hbv_joint_parameter_synthetic_mechanism_gate.py": (
        "65d8528929ecb5bf15d71c9fb432e1d39a0957bc2d12762d95bac235aa355b45"
    ),
    "scripts/differentiable_ukf_hbvlite.py": (
        "5d4d0fce3018aef42d6ef81ac32fa97541654f0a878c0508f5594ff2ec73c02d"
    ),
    "scripts/tukf10_joint_hbv_physical_filter_common.py": (
        "44e594c6eeac07e1f5f2a27c2fc2a0856a48fa59d6ddb8e0378373bed80e3b80"
    ),
    "scripts/run_aligned_gr4j_da.py": (
        "02785f2377a36454ce21127553e93c58d8c356b6f53ddbc10ee3e2f9370ec926"
    ),
    "scripts/run_aligned_gr4j_differentiable_ukf.py": (
        "a8bae71dc1007c3b0502e81e50e766328202996aaf370987a347041ddde0d23f"
    ),
    "src/global_hydrology/assimilation/conventional_ukf.py": (
        "2c1a17f0d48962ab8ac7c68c0ae8edaf0ad616f938a6466f0925d27ee9258c3a"
    ),
    "src/global_hydrology/models/trainable_hbvlite_ukf_adapter.py": (
        "4c4ef11f5a22e50aeb2817031785d021906480cb8937985188444e32a4abee54"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "d7a04be86f19cddd8b9703e432fafb999a38215cb85de8983fe39a40bda0d6ea"
    ),
    "G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/hbv_lite_numpy.py": (
        "8c6356926fd6b4bdef672c4ea56bc7941291ee05298dd461100e919beb590103"
    ),
}
EXPECTED_CLAIMS_NOT_AUTHORIZED = [
    "hydrologic parameter identifiability",
    "filter-noise parameter identifiability",
    "physical identification of process or observation noise",
    "recovery from an erroneous initial state",
    "online test-period parameter learning",
    "real-catchment forecast validity",
    "forecast value under forcing forecast error",
    "causal interpretation of the two-factor interaction",
    "matched no-noise or open-loop calibration conclusions",
    "replacement of any sealed predecessor verdict",
    "scientific success from technical verification alone",
]


# Audited numerical and serialization primitives.  TUKF20 owns no alternate
# implementation of these operations.
read_json = base.read_json
jsonable = base.jsonable
write_new_json = base.write_new_json
write_new_npz = base.write_new_npz
sha256_file = base.sha256_file
sha256_arrays = base.sha256_arrays
copy_snapshot = base.copy_snapshot
resolve_readonly_input = base.resolve_readonly_input
predecessor_root = base.predecessor_root
predecessor_modules = base.predecessor_modules
parent_contracts = base.parent_contracts
truth_process_variances = base.truth_process_variances
generate_truth_for_seed = base.generate_truth_for_seed
mechanically_accept_truth_seed = base.mechanically_accept_truth_seed
origin_indices = base.origin_indices
rollout_state_update_trace = base.rollout_state_update_trace
forecast_from_origin_states = base.forecast_from_origin_states
rolling_origin_objective = base.rolling_origin_objective
state_error_metrics = base.state_error_metrics
snapshot_model = base.snapshot_model
restore_model_ = base.restore_model_
classify_balance_arrays = base.classify_balance_arrays
build_start_values = balance.build_start_values
build_model = balance.build_model


def _delegated_source_path(
    contract: Mapping[str, Any], specification: Mapping[str, Any]
) -> Path:
    raw = Path(str(specification["path"]))
    if raw.is_absolute() or ".." in raw.parts:
        raise ValueError("delegated numerical sources must use safe relative paths")
    scope = specification.get("scope")
    if scope == "isolated_worktree":
        root = ROOT.resolve()
    elif scope == "readonly_predecessor":
        root = predecessor_root(contract)
    else:
        raise ValueError(f"unknown delegated numerical source scope: {scope}")
    candidate = (root / raw).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as error:
        raise ValueError("delegated numerical source escapes its registered root") from error
    return candidate


def resolve_output_path(contract: Mapping[str, Any], raw: Path | str) -> Path:
    """Resolve only an exact frozen TUKF20 root or one of its descendants."""

    value = Path(str(raw))
    if value.is_absolute() or ".." in value.parts:
        raise ValueError("TUKF20 output paths must be safe worktree-relative paths")
    candidate = (ROOT / value).resolve()
    allowed = tuple((ROOT / registered).resolve() for registered in EXPECTED_OUTPUTS.values())
    if not any(candidate == root or root in candidate.parents for root in allowed):
        raise ValueError(f"path is not within a frozen TUKF20 output root: {raw}")
    try:
        candidate.relative_to(ROOT.resolve())
    except ValueError as error:
        raise ValueError("TUKF20 output path escapes the isolated worktree") from error
    return candidate


def _require_exact(actual: Any, expected: Any, message: str) -> None:
    if actual != expected:
        raise ValueError(message)


def validate_contract(
    contract: Mapping[str, Any], *, verify_files: bool = True,
    configuration_path: Path | str = DEFAULT_CONFIG,
) -> dict[str, Any]:
    """Reject any change to the frozen scientific or evidence contract."""

    _require_exact(
        contract.get("schema_version"), SCHEMA_VERSION,
        "unexpected TUKF20 schema version",
    )
    _require_exact(
        contract.get("experiment_id"), EXPERIMENT_ID,
        "unexpected TUKF20 experiment identifier",
    )
    _require_exact(
        contract.get("status"),
        "SCIENTIFIC_CONTRACT_FROZEN_IMPLEMENTATION_AUTHORIZED",
        "TUKF20 authorization status changed",
    )
    _require_exact(
        contract.get("authorization"), EXPECTED_AUTHORIZATION,
        "TUKF20 authorization boundary changed",
    )
    _require_exact(
        contract.get("readonly_predecessor_root"),
        "G:/github/pycharm/projects/kalmannet",
        "read-only predecessor root changed",
    )
    _require_exact(
        contract.get("parent_configs"), EXPECTED_PARENT_CONFIGS,
        "predecessor configuration paths changed",
    )
    _require_exact(
        contract.get("delegated_numerical_sources"), EXPECTED_DELEGATED_SOURCES,
        "delegated numerical sources changed",
    )
    _require_exact(
        tuple(contract.get("mode_order", ())), PIPELINE_ORDER,
        "four-mode order changed",
    )
    _require_exact(
        contract.get("mode_masks"), EXPECTED_MODE_MASKS,
        "four-mode trainability mode masks changed",
    )
    _require_exact(
        contract.get("mode_state_update"), EXPECTED_MODE_STATE_UPDATE,
        "state-update policy changed",
    )
    _require_exact(
        contract.get("display_labels"), EXPECTED_DISPLAY_LABELS,
        "display labels changed",
    )
    _require_exact(
        tuple(contract.get("readout_order", ())), READOUT_ORDER,
        "readout order changed",
    )
    _require_exact(
        contract.get("readout_grid"), EXPECTED_READOUT_GRID,
        "state-updating readout grid changed",
    )
    _require_exact(
        contract.get("primary_contrasts"), EXPECTED_PRIMARY_CONTRASTS,
        "primary contrast definitions changed",
    )
    _require_exact(
        contract.get("secondary_contrasts"), EXPECTED_SECONDARY_CONTRASTS,
        "secondary contrast definitions changed",
    )
    _require_exact(
        contract.get("two_factor_interaction"), EXPECTED_INTERACTION,
        "two-factor interaction boundary changed",
    )
    _require_exact(
        contract.get("balanced_error_design"), EXPECTED_BALANCED_DESIGN,
        "balanced error design changed",
    )
    _require_exact(
        contract.get("truth_seed_policy"), EXPECTED_SEED_POLICY,
        "truth seed policy changed",
    )
    _require_exact(
        contract.get("truth_and_filter"), EXPECTED_TRUTH_AND_FILTER,
        "truth and filter configuration changed",
    )
    origins = contract.get("origins", {})
    for split, expected in EXPECTED_ORIGINS.items():
        _require_exact(
            origins.get(split), expected, f"{split} origin window changed"
        )
    _require_exact(
        contract.get("objective"), EXPECTED_OBJECTIVE,
        "rolling-origin objective changed",
    )
    _require_exact(
        contract.get("optimizer"), EXPECTED_OPTIMIZER,
        "optimizer contract changed",
    )
    _require_exact(
        contract.get("selection"), EXPECTED_SELECTION,
        "selection contract changed",
    )
    _require_exact(
        contract.get("seals_and_budget"), EXPECTED_BUDGET,
        "formal budget changed",
    )
    _require_exact(
        contract.get("gates"), EXPECTED_GATES,
        "clear-benefit gates changed",
    )
    _require_exact(
        contract.get("scientific_decision"), EXPECTED_SCIENTIFIC_DECISION,
        "scientific decision and stop rule changed",
    )
    _require_exact(
        contract.get("balance_preflight"), EXPECTED_BALANCE_PREFLIGHT,
        "balance preflight changed",
    )
    _require_exact(
        contract.get("resources"), EXPECTED_RESOURCES,
        "resource admission thresholds changed",
    )
    _require_exact(
        contract.get("numerical_environment"), EXPECTED_NUMERICAL_ENVIRONMENT,
        "numerical environment changed",
    )
    _require_exact(
        contract.get("outputs"), EXPECTED_OUTPUTS,
        "TUKF20 output roots changed",
    )
    _require_exact(
        contract.get("readonly_input_sha256"), EXPECTED_READONLY_INPUT_SHA256,
        "read-only input closure changed",
    )
    _require_exact(
        contract.get("claims_not_authorized"), EXPECTED_CLAIMS_NOT_AUTHORIZED,
        "claims-not-authorized boundary changed",
    )
    for raw in EXPECTED_OUTPUTS.values():
        resolve_output_path(contract, raw)

    verified_readonly = 0
    verified_delegated = 0
    if verify_files:
        configuration = Path(configuration_path).resolve()
        if not configuration.is_file():
            raise FileNotFoundError(f"TUKF20 configuration is missing: {configuration}")
        if read_json(configuration) != dict(contract):
            raise ValueError("in-memory contract differs from its configuration file")
        for raw, expected in EXPECTED_READONLY_INPUT_SHA256.items():
            path = resolve_readonly_input(contract, raw)
            if not path.is_file():
                raise FileNotFoundError(f"registered read-only input is missing: {path}")
            if sha256_file(path) != expected:
                raise ValueError(f"read-only input SHA-256 mismatch: {raw}")
            verified_readonly += 1
        for label, specification in EXPECTED_DELEGATED_SOURCES.items():
            path = _delegated_source_path(contract, specification)
            if not path.is_file():
                raise FileNotFoundError(
                    f"delegated numerical source is missing: {label}: {path}"
                )
            if sha256_file(path) != specification["sha256"]:
                raise ValueError(
                    f"delegated numerical source SHA-256 mismatch: {label}"
                )
            verified_delegated += 1
    return {
        "mode_count": len(PIPELINE_ORDER),
        "state_updating_mode_count": len(PIPELINE_ORDER),
        "independent_replicates": 27,
        "verified_readonly_inputs": verified_readonly,
        "verified_delegated_sources": verified_delegated,
        "scientific_contract_frozen": True,
    }


def load_contract(path: Path | str = DEFAULT_CONFIG) -> dict[str, Any]:
    contract = read_json(path)
    validate_contract(contract, configuration_path=path)
    return contract


def source_hashes(
    contract: Mapping[str, Any], configuration_path: Path | str = DEFAULT_CONFIG
) -> dict[str, str]:
    """Verify and report the complete numerical-source closure."""

    validate_contract(
        contract, verify_files=True, configuration_path=configuration_path
    )
    runtime_sources = {
        "joint_learning_common": Path(__file__).resolve(),
        "mode_training": ROOT / "scripts" / "tukf20_hbv_rolling_origin_mode_training.py",
        "formal_runner": ROOT
        / "scripts"
        / "run_tukf20_hbv_rolling_origin_joint_learning.py",
        "independent_verifier": ROOT
        / "scripts"
        / "verify_tukf20_hbv_rolling_origin_joint_learning.py",
        "rolling_readout_engine": ROOT
        / "scripts"
        / "run_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "rolling_verification_reference": ROOT
        / "scripts"
        / "verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    }
    missing = [str(path) for path in runtime_sources.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"TUKF20 runtime source is missing: {missing}")
    result = {
        "configuration:contract": sha256_file(configuration_path),
        **{
            f"source:{label}": sha256_file(path)
            for label, path in runtime_sources.items()
        },
    }
    for label, specification in contract["delegated_numerical_sources"].items():
        path = _delegated_source_path(contract, specification)
        actual = sha256_file(path)
        if actual != str(specification["sha256"]):
            raise ValueError(f"delegated numerical source SHA-256 mismatch: {label}")
        result[f"delegated:{label}"] = actual
    for raw, expected in contract["readonly_input_sha256"].items():
        path = resolve_readonly_input(contract, raw)
        actual = sha256_file(path)
        if actual != str(expected):
            raise ValueError(f"read-only input SHA-256 mismatch: {raw}")
        result[f"readonly:{raw}"] = actual
    return result


def _prior_attempted_seed_set(contract: Mapping[str, Any]) -> set[int]:
    result: set[int] = set()
    for bounds in contract["truth_seed_policy"][
        "prior_attempted_seed_intervals"
    ].values():
        lower, upper = (int(value) for value in bounds)
        result.update(range(lower, upper + 1))
    return result


def freeze_seed_registry(
    contract: Mapping[str, Any], *, destination: Path | str | None = None,
    configuration_path: Path | str = DEFAULT_CONFIG,
) -> dict[str, Any]:
    """Freeze the first 27 mechanically valid, predecessor-disjoint truth seeds."""

    validate_contract(
        contract, verify_files=True, configuration_path=configuration_path
    )
    policy = contract["truth_seed_policy"]
    accepted_target = int(policy["accepted_count"])
    candidate = int(policy["first_candidate"])
    step = int(policy["candidate_step"])
    prior_attempts = _prior_attempted_seed_set(contract)
    attempts: list[dict[str, Any]] = []
    accepted: list[dict[str, Any]] = []
    while len(accepted) < accepted_target:
        if candidate in prior_attempts:
            raise RuntimeError(
                f"TUKF20 candidate overlaps a prior attempted seed: {candidate}"
            )
        row = mechanically_accept_truth_seed(candidate, contract)
        if int(row.get("scientific_metric_queries", -1)) != 0:
            raise PermissionError("mechanical seed selection queried a scientific metric")
        attempts.append(row)
        if bool(row["accepted"]):
            accepted.append(
                {
                    "accepted_order": len(accepted) + 1,
                    "truth_seed": candidate,
                    "start_id": START_IDS[len(accepted)],
                    "truth_array_sha256": row.get("truth_array_sha256"),
                }
            )
        candidate += step
    registry = {
        "schema_version": "tukf20_truth_seed_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "UNSEEN_TRUTH_SEEDS_MECHANICALLY_FROZEN",
        "candidate_start": int(policy["first_candidate"]),
        "attempted_candidates": attempts,
        "accepted_pairs": accepted,
        "accepted_count": len(accepted),
        "scientific_metric_queries": 0,
        "prior_attempted_seed_overlap_count": 0,
        "truth_generator_sha256": contract["readonly_input_sha256"][
            "scripts/tukf11_hbv_joint_parameter_synthetic_common.py"
        ],
        "configuration_sha256": sha256_file(configuration_path),
    }
    target = destination
    if target is None:
        target = (
            resolve_output_path(contract, contract["outputs"]["preflight_root"])
            / "seed_registry.json"
        )
    write_new_json(target, registry)
    return registry


def registered_pairs(
    contract: Mapping[str, Any], registry: Mapping[str, Any]
) -> tuple[tuple[int, str], ...]:
    """Validate the exclusive TUKF20 seed/start registry and return its pairs."""

    prior_attempts = _prior_attempted_seed_set(contract)
    attempted_rows = tuple(registry.get("attempted_candidates", ()))
    attempted_seeds = tuple(int(row["seed"]) for row in attempted_rows)
    if any(seed in prior_attempts for seed in attempted_seeds):
        raise ValueError("seed registry contains a prior attempted seed")

    validate_contract(contract, verify_files=False)
    if registry.get("schema_version") != "tukf20_truth_seed_registry_v1":
        raise ValueError("unexpected TUKF20 seed registry schema")
    if registry.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("seed registry belongs to another experiment")
    if registry.get("status") != "UNSEEN_TRUTH_SEEDS_MECHANICALLY_FROZEN":
        raise ValueError("seed registry is not mechanically frozen")
    policy = contract["truth_seed_policy"]
    first = int(policy["first_candidate"])
    step = int(policy["candidate_step"])
    expected_attempts = tuple(first + step * index for index in range(len(attempted_rows)))
    if attempted_seeds != expected_attempts:
        raise ValueError("attempted truth seeds are not contiguous from the frozen start")
    if any(int(row.get("scientific_metric_queries", -1)) != 0 for row in attempted_rows):
        raise PermissionError("seed selection used a scientific metric")
    if int(registry.get("candidate_start", -1)) != first:
        raise ValueError("seed registry candidate start changed")
    if int(registry.get("scientific_metric_queries", -1)) != 0:
        raise PermissionError("seed selection used a scientific metric")
    if int(registry.get("prior_attempted_seed_overlap_count", -1)) != 0:
        raise ValueError("seed registry reports prior attempted seed overlap")

    rows = tuple(registry.get("accepted_pairs", ()))
    pairs = tuple((int(row["truth_seed"]), str(row["start_id"])) for row in rows)
    if int(registry.get("accepted_count", -1)) != 27 or len(pairs) != 27:
        raise ValueError("seed registry must contain exactly 27 accepted pairs")
    if len(set(pairs)) != 27 or len({seed for seed, _ in pairs}) != 27:
        raise ValueError("every formal repetition requires a unique truth seed")
    if tuple(start for _, start in pairs) != START_IDS:
        raise ValueError("accepted seeds are not mapped to start_03 through start_29")
    if any(
        int(row.get("accepted_order", -1)) != index
        for index, row in enumerate(rows, 1)
    ):
        raise ValueError("accepted seed order is not contiguous")
    accepted_attempts = tuple(
        int(row["seed"]) for row in attempted_rows if bool(row.get("accepted"))
    )
    if accepted_attempts[:27] != tuple(seed for seed, _ in pairs):
        raise ValueError("accepted pairs differ from mechanically accepted attempts")
    if not attempted_seeds or attempted_seeds[-1] != pairs[-1][0]:
        raise ValueError("seed registry continued beyond the twenty-seventh acceptance")
    return pairs


def _binomial_tail_fraction(successes: int, trials: int) -> Fraction:
    return Fraction(
        sum(math.comb(trials, value) for value in range(successes, trials + 1)),
        2**trials,
    )


def classify_contrast(
    ratios: Sequence[float], contract: Mapping[str, Any]
) -> str:
    values = np.asarray(ratios, dtype=np.float64)
    replicates = int(contract["gates"]["independent_replicates"])
    if (
        values.shape != (replicates,)
        or not np.isfinite(values).all()
        or np.any(values <= 0.0)
    ):
        raise ValueError(
            f"contrast requires {replicates} finite positive paired ratios"
        )
    median = float(np.median(values))
    wins = int(np.count_nonzero(values < 1.0))
    losses = int(np.count_nonzero(values > 1.0))
    minimum = int(contract["gates"]["minimum_direction_count"])
    alpha = float(contract["gates"]["sign_test_one_sided_alpha"])
    benefit_p = float(_binomial_tail_fraction(wins, replicates))
    harm_p = float(_binomial_tail_fraction(losses, replicates))
    if (
        median
        <= float(contract["gates"]["clear_benefit_median_ratio_maximum"])
        and wins >= minimum
        and benefit_p <= alpha
    ):
        return "CLEAR_BENEFIT"
    if (
        median >= float(contract["gates"]["clear_harm_median_ratio_minimum"])
        and losses >= minimum
        and harm_p <= alpha
    ):
        return "CLEAR_HARM"
    if (
        float(contract["gates"]["clear_benefit_median_ratio_maximum"])
        < median
        < float(contract["gates"]["clear_harm_median_ratio_minimum"])
        and (wins >= minimum or losses >= minimum)
    ):
        return "DIRECTIONAL_SMALL"
    return "MIXED_OR_INCONCLUSIVE"


def _index_readout_rows(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> tuple[
    dict[tuple[int, str, str], Mapping[str, Any]],
    tuple[tuple[int, str], ...],
]:
    del contract
    indexed: dict[tuple[int, str, str], Mapping[str, Any]] = {}
    for row in rows:
        key = (
            int(row["truth_seed"]),
            str(row["start_id"]),
            str(row["readout_id"]),
        )
        if key in indexed:
            raise ValueError(f"duplicate readout row: {key}")
        indexed[key] = row
    pair_set = {(seed, start) for seed, start, _ in indexed}
    if (
        len(pair_set) != 27
        or len({seed for seed, _ in pair_set}) != 27
        or {start for _, start in pair_set} != set(START_IDS)
    ):
        raise ValueError("readout rows do not contain 27 independent registered pairs")
    pairs = tuple(sorted(pair_set, key=lambda pair: START_IDS.index(pair[1])))
    expected = {
        (seed, start, readout)
        for seed, start in pairs
        for readout in READOUT_ORDER
    }
    if set(indexed) != expected:
        raise ValueError("four-mode state-updating test product is incomplete")
    return indexed, pairs


def _checked_metric(row: Mapping[str, Any], name: str) -> float:
    value = float(row[name])
    if not math.isfinite(value) or value <= 0.0:
        raise ValueError("primary clean errors must be finite and positive")
    return value


def _contrast_summary(
    indexed: Mapping[tuple[int, str, str], Mapping[str, Any]],
    pairs: Sequence[tuple[int, str]],
    numerator: str,
    denominator: str,
    contract: Mapping[str, Any],
) -> dict[str, Any]:
    ratios: list[float] = []
    per_pair: list[dict[str, Any]] = []
    for seed, start_id in pairs:
        numerator_value = _checked_metric(
            indexed[(seed, start_id, numerator)], "primary_clean_mse"
        )
        denominator_value = _checked_metric(
            indexed[(seed, start_id, denominator)], "primary_clean_mse"
        )
        ratio = numerator_value / denominator_value
        ratios.append(ratio)
        per_pair.append(
            {"truth_seed": seed, "start_id": start_id, "ratio": ratio}
        )
    values = np.asarray(ratios, dtype=np.float64)
    wins = int(np.count_nonzero(values < 1.0))
    losses = int(np.count_nonzero(values > 1.0))
    win_tail = _binomial_tail_fraction(wins, len(ratios))
    loss_tail = _binomial_tail_fraction(losses, len(ratios))
    by_lead: dict[str, Any] = {}
    for lead in LEADS:
        lead_ratios: list[float] = []
        for seed, start in pairs:
            numerator_value = float(
                indexed[(seed, start, numerator)]["primary_clean_mse_by_lead"][
                    str(lead)
                ]
            )
            denominator_value = float(
                indexed[(seed, start, denominator)]["primary_clean_mse_by_lead"][
                    str(lead)
                ]
            )
            if not (
                math.isfinite(numerator_value)
                and math.isfinite(denominator_value)
                and numerator_value > 0.0
                and denominator_value > 0.0
            ):
                raise ValueError("per-lead primary clean errors must be finite and positive")
            lead_ratios.append(numerator_value / denominator_value)
        lead_values = np.asarray(lead_ratios, dtype=np.float64)
        by_lead[str(lead)] = {
            "median_ratio": float(np.median(lead_values)),
            "ratio_range": [min(lead_ratios), max(lead_ratios)],
            "wins_below_one": int(np.count_nonzero(lead_values < 1.0)),
            "losses_above_one": int(np.count_nonzero(lead_values > 1.0)),
            "ties_at_one": int(np.count_nonzero(lead_values == 1.0)),
            "ratios": lead_ratios,
        }
    return {
        "numerator": numerator,
        "denominator": denominator,
        "per_pair_ratios": per_pair,
        "ratios": ratios,
        "median_ratio": float(np.median(values)),
        "ratio_range": [min(ratios), max(ratios)],
        "wins_below_one": wins,
        "losses_above_one": losses,
        "ties_at_one": len(ratios) - wins - losses,
        "win_fraction_exact_95_percent_interval": base._clopper_pearson(
            wins, len(ratios)
        ),
        "benefit_sign_test_one_sided_p": float(win_tail),
        "benefit_sign_test_fraction": [win_tail.numerator, win_tail.denominator],
        "harm_sign_test_one_sided_p": float(loss_tail),
        "harm_sign_test_fraction": [loss_tail.numerator, loss_tail.denominator],
        "classification": classify_contrast(ratios, contract),
        "by_lead": by_lead,
    }


def aggregate_primary_pipelines(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> dict[str, Any]:
    indexed, pairs = _index_readout_rows(rows, contract)
    contrasts = {
        name: _contrast_summary(
            indexed,
            pairs,
            str(specification["numerator"]),
            str(specification["denominator"]),
            contract,
        )
        for name, specification in contract["primary_contrasts"].items()
    }
    ratios: list[float] = []
    per_pair: list[dict[str, Any]] = []
    for seed, start in pairs:
        values = {
            readout: _checked_metric(
                indexed[(seed, start, readout)], "primary_clean_mse"
            )
            for readout in READOUT_ORDER
        }
        ratio = (
            values["joint"] * values["all_frozen"]
        ) / (values["hydrology_only"] * values["filter_only"])
        ratios.append(ratio)
        per_pair.append(
            {
                "truth_seed": seed,
                "start_id": start,
                "interaction_ratio": ratio,
                "log_interaction_ratio": math.log(ratio),
            }
        )
    ratio_values = np.asarray(ratios, dtype=np.float64)
    below = int(np.count_nonzero(ratio_values < 1.0))
    above = int(np.count_nonzero(ratio_values > 1.0))
    alpha = float(contract["gates"]["sign_test_one_sided_alpha"])
    return {
        "independent_unit": "unique_truth_seed_and_registered_start_pair",
        "independent_unit_count": 27,
        "contrasts": contrasts,
        "interaction": {
            "formula": contract["two_factor_interaction"]["formula"],
            "descriptive_only": True,
            "causal_or_success_gate": False,
            "per_pair": per_pair,
            "median_ratio": float(np.median(ratio_values)),
            "ratio_range": [min(ratios), max(ratios)],
            "below_one_count": below,
            "above_one_count": above,
            "ties_at_one": len(ratios) - below - above,
            "below_one_fraction_exact_95_percent_interval": (
                base._clopper_pearson(below, len(ratios), alpha=alpha)
            ),
            "above_one_fraction_exact_95_percent_interval": (
                base._clopper_pearson(above, len(ratios), alpha=alpha)
            ),
        },
    }


def aggregate_crossed_readouts(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> dict[str, Any]:
    """Return the two registered secondary contrast summaries directly."""

    indexed, pairs = _index_readout_rows(rows, contract)
    return {
        name: _contrast_summary(
            indexed,
            pairs,
            str(specification["numerator"]),
            str(specification["denominator"]),
            contract,
        )
        for name, specification in contract["secondary_contrasts"].items()
    }


def classify_mechanisms(
    aggregate: Mapping[str, Any], contract: Mapping[str, Any]
) -> dict[str, Any]:
    primary_payload = aggregate["primary"]
    primary = (
        primary_payload["contrasts"]
        if "contrasts" in primary_payload
        else primary_payload
    )
    crossed = aggregate.get("crossed", {})
    primary_classes = {
        name: str(primary[name]["classification"])
        for name in contract["primary_contrasts"]
    }
    secondary_classes = {
        name: str(crossed[name]["classification"])
        for name in contract["secondary_contrasts"]
        if name in crossed
    }
    all_clear = all(
        value == "CLEAR_BENEFIT" for value in primary_classes.values()
    )
    decision = contract["scientific_decision"]
    return {
        "overall_status": (
            decision["success_label"] if all_clear else decision["failure_label"]
        ),
        "primary_classes": primary_classes,
        "secondary_classes": secondary_classes,
        "all_primary_clear_benefit": all_clear,
        "two_factor_interaction_descriptive_only": True,
        "scientific_retuning_allowed": False,
    }
