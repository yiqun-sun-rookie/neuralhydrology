# TUKF20 Rolling-Origin Joint Learning Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Determine whether learning hydrologic-model parameters and state-estimation noise parameters through the same daily state-update computation improves one-to-three-day synthetic discharge forecasts, and whether joint learning adds value beyond learning either parameter group alone.

**Architecture:** Create a new four-mode rolling-origin experiment. Every mode performs the identical daily prediction and observation update; the only factors are whether the twelve hydrologic parameters and the nine state-estimation noise parameters are trainable. Reuse the audited rolling-origin numerical primitives and balanced-start construction, but implement new mode ownership, checkpoint sealing, aggregation, independent verification, plotting, and high-performance-computing deployment under TUKF20-only paths.

**Tech Stack:** Python 3.11, PyTorch float64 on one central-processing-unit thread, NumPy, pytest, JSON/NPZ evidence artifacts, Slurm, and the Git mailbox channel `kalmannet-tukf20`.

## Global Constraints

- Work only in `G:\github\pycharm\projects\kalmannet-tukf17-implementation-20260823` and the TUKF20-only Git-mailbox paths listed below.
- Treat `G:\github\pycharm\projects\kalmannet` and all TUKF16-TUKF19 files, results, and artifacts as read-only evidence.
- Preserve the unrelated existing modification `draft/hydroshare_package/environment.yml` and every unrelated untracked file.
- Do not commit, push, publish, clean, delete, overwrite, or reinterpret predecessor evidence.
- Do not add the matched no-noise/open-loop parameter-calibration diagnostic. It does not directly answer the final joint-learning decision.
- Technical verification, scientific balance, and scientific success are three distinct statuses.
- A technical failure may be repaired only with the same frozen scientific contract and a new non-overwriting path. An unfavorable scientific result is not a technical failure and cannot justify retuning or rerunning.
- Before every high-performance-computing action, follow `G:\github\pycharm\projects\neuralhydrology\docs\hpc\HPC_PLAYBOOK.md` and `HPC_AGENT_GUIDE.md`; the login node may perform only light Git, file, Slurm-submission, and status operations.
- The user's current approval authorizes implementation, the gated smoke job, and the single formal paid job after the smoke gate passes. It does not authorize repository commits, publication, cleanup, or changes to the frozen scientific contract.

---

### Task 1: Freeze the TUKF20 scientific contract

**Files:**
- Create: `configs/tukf20_hbv_rolling_origin_joint_learning_v1.json`
- Create: `scripts/tukf20_hbv_rolling_origin_joint_learning_common.py`
- Test: `tests/test_tukf20_hbv_rolling_origin_joint_learning.py`

- [ ] Add a failing contract test that requires exactly four modes: `all_frozen`, `hydrology_only`, `filter_only`, and `joint`.
- [ ] Require `state_update: true` in training, selection, and test for all four modes.
- [ ] Freeze the trainability masks as `(false,false)`, `(true,false)`, `(false,true)`, and `(true,true)` for hydrologic and filter-noise parameters respectively.
- [ ] Freeze three primary contrasts: `joint_over_all_frozen`, `joint_over_hydrology_only`, and `joint_over_filter_only`.
- [ ] Register `hydrology_only_over_all_frozen` and `filter_only_over_all_frozen` as secondary contrasts; register the two-factor interaction as descriptive only.
- [ ] Freeze the rolling origins at training days 27-104, selection days 107-144, and test days 147-188, with shared one-, two-, and three-day forecast origins and equal lead weights.
- [ ] Freeze noisy synthetic discharge as the training and selection target, clean synthetic discharge as the primary test target, and noisy synthetic discharge as the secondary test target.
- [ ] Freeze exact initial state, perfect future forcing, process standard-deviation fraction `0.02`, hydrologic normalized-coordinate distance `0.05`, and filter-noise perturbation factor `8.0`.
- [ ] Freeze a new seed policy beginning at 1901. Accept the first 27 seeds passing only the four mechanical truth checks, map them in order to `start_03` through `start_29`, and prove disjointness from all attempted TUKF17 and TUKF18 seed sets, including TUKF18's attempted interval 1801-1832.
- [ ] Freeze Adam learning rates `0.005` for hydrologic parameters and `0.05` for filter-noise parameters, independent group gradient clipping at `1.0`, 96 updates, selection queries at `0,4,...,96`, and earliest-update tie breaking.
- [ ] Freeze the exact budget: 108 mode cells, 81 trainable cells, 7,776 optimizer updates, 2,052 selection queries, 108 selected checkpoints, 108 state-updating test readouts, 126 clean test errors per readout, and 13,608 clean test errors overall.
- [ ] Freeze the clear-benefit rule for every primary contrast: median error ratio at most `0.90`, at least 19 of 27 paired improvements, and one-sided exact sign-test probability at most `0.05`.
- [ ] Define overall scientific success as all three primary contrasts satisfying clear benefit. If any primary contrast fails, report `FINAL_JOINT_ADVANTAGE_NOT_ESTABLISHED` and stop scientific retuning.
- [ ] Freeze balance preflight: all eight train/selection influence ratios must lie in `[1/3,3]`; no test metric may be queried; one failure stops formal execution without a replacement setting under this experiment identifier.
- [ ] Lock all read-only input and delegated numerical-source SHA-256 values and reject contract drift.
- [ ] Implement path resolution that permits only new TUKF20 output roots.
- [ ] Run `python -m pytest tests/test_tukf20_hbv_rolling_origin_joint_learning.py -q` and require all tests to pass.

### Task 2: Implement four-mode training and checkpoint sealing

**Files:**
- Create: `scripts/tukf20_hbv_rolling_origin_mode_training.py`
- Test: `tests/test_tukf20_hbv_rolling_origin_runner.py`

- [ ] Write failing tests for each mode's `requires_grad` ownership and optimizer parameter-group names, learning rates, and membership.
- [ ] Implement parameter ownership for twelve hydrologic coordinates, eight process-noise diagonal values, and one observation-noise ratio.
- [ ] Implement a separate gradient-finiteness and norm-clipping check for each active parameter group; reject any gradient on a frozen group.
- [ ] Snapshot all parameter groups before training and prove every frozen group remains byte-for-byte unchanged after every optimizer update and after checkpoint restoration.
- [ ] For every trainable mode and every optimizer step, call the same rolling-origin objective with `state_update=True`; do not expose a mode-specific path that can turn state updating off.
- [ ] Project trainable coordinates to their registered physical bounds after each update and record boundary-contact diagnostics without treating boundary contact as a technical failure.
- [ ] Record update-zero and every fourth-update selection checkpoint, selection loss by forecast lead, active-group gradient counts and norms, full parameter snapshots, file hashes, and the chosen update.
- [ ] Treat a mode as trainable when either hydrologic or filter-noise parameters are active, so `filter_only` cannot be forced to update zero.
- [ ] Implement a global selection seal that requires all 108 mode checkpoints, exactly 7,776 updates and 2,052 selection queries, and zero clean-test-target and test-observation queries before sealing.
- [ ] Run `python -m pytest tests/test_tukf20_hbv_rolling_origin_runner.py -q` and require all tests to pass.

### Task 3: Implement preflight and formal orchestration

**Files:**
- Create: `scripts/run_tukf20_hbv_rolling_origin_joint_learning.py`
- Modify: `tests/test_tukf20_hbv_rolling_origin_runner.py`

- [ ] Add tests that preflight creates only a new TUKF20 preflight root and refuses an existing preflight, result, or failed-attempt root.
- [ ] Implement mechanical seed freezing and the eight-ratio balance calculation using only training and selection windows.
- [ ] Write `seed_registry.json`, `balance_errors.npz`, `balance_gate.json`, and `preflight.json` with source and configuration hashes, zero formal optimizer updates, and zero test queries.
- [ ] Require a passing independent preflight verification with identical source/configuration hashes before formal execution.
- [ ] During formal execution, train all four modes for each of the 27 frozen pairs, write the global selection seal, and only then permit test readout.
- [ ] Restore the selected snapshot for each mode, freeze both parameter groups, stream daily state updates through test origins, and prohibit all test-period parameter updates and future-observation use.
- [ ] Write one truth array product per pair, one test array and metric product per mode, paired contrast aggregates, per-lead statistics, exact sign tests, source hashes at start/end, resource admission, and a non-overwriting manifest.
- [ ] Classify overall status only after all three primary contrast classifications exist; never convert an engineering pass into scientific success.
- [ ] Archive a technically failed partial run under a unique timestamped failed-attempt directory without overwriting or deleting the partial evidence.
- [ ] Run `python -m pytest tests/test_tukf20_hbv_rolling_origin_runner.py -q` and require all tests to pass.

### Task 4: Implement independent verification

**Files:**
- Create: `scripts/verify_tukf20_hbv_rolling_origin_joint_learning.py`
- Create: `tests/test_verify_tukf20_hbv_rolling_origin_joint_learning.py`

- [ ] Add an abstract-syntax-tree test proving the verifier does not import the formal runner or mode-training module.
- [ ] Independently validate the contract, source closure, output manifest, seed mechanical acceptance, prior-seed disjointness, balance arrays, and all eight balance ratios.
- [ ] Independently read every selection checkpoint, recompute each selection loss, reproduce earliest-update selection, and enforce the per-mode active/frozen parameter masks.
- [ ] Independently rebuild 108 causal state-updating test readouts and all 13,608 primary clean squared errors from frozen checkpoints, forcing, observations, and truth arrays.
- [ ] Recompute clean/noisy mean squared errors by lead, complete-state diagnostics, covariance arrays, parameter values, paired ratios, exact sign tests, confidence intervals, and all primary/secondary classifications.
- [ ] Fail verification after any checkpoint, metric row, array, manifest, configuration, or source-hash mutation.
- [ ] Emit `FORMAL_VERIFIED` only when all engineering and evidence checks pass. Emit a separate scientific conclusion based solely on the three preregistered primary contrasts.
- [ ] Run `python -m pytest tests/test_verify_tukf20_hbv_rolling_origin_joint_learning.py -q` and require all tests to pass.

### Task 5: Implement verified plotting

**Files:**
- Create: `scripts/plot_tukf20_hbv_rolling_origin_joint_learning.py`
- Modify: `tests/test_verify_tukf20_hbv_rolling_origin_joint_learning.py`

- [ ] Require `FORMAL_VERIFIED` input and matching result/verification hashes before reading scientific results.
- [ ] Read contrast names and ordering from the frozen configuration; do not hard-code a contrast absent from the registry.
- [ ] Select the representative pair mechanically as the pair whose `joint_over_all_frozen` ratio is closest to the registered median, with truth seed and start identifier as deterministic tie breakers.
- [ ] Generate separate figures for three primary paired-error ratios, one-/two-/three-day ratios, representative four-mode hydrographs, learned hydrologic-parameter displacement, and learned process/observation-noise displacement relative to truth.
- [ ] Write a figure manifest containing every input hash, representative-pair rule/result, plotted numerical values, file size, and SHA-256.
- [ ] Run the plotting tests and verify every configured figure exists and has a nonzero size.

### Task 6: Build a deterministic high-performance-computing deployment

**Files:**
- Create: `configs/tukf20_hpc_deployment_v1.json`
- Create: `scripts/tukf20_hpc_deployment_common.py`
- Create: `scripts/build_tukf20_hpc_bundle.py`
- Create: `scripts/smoke_tukf20_hpc_compatibility.py`
- Create: `scripts/run_tukf20_hpc_formal_pipeline.py`
- Create: `hpc/tukf20_hbv_rolling_origin_joint_learning/submit_smoke_cpu.slurm`
- Create: `hpc/tukf20_hbv_rolling_origin_joint_learning/submit_formal_cpu.slurm`
- Create: `tests/test_tukf20_hpc_migration.py`

- [ ] Freeze Git-mailbox channel `kalmannet-tukf20`, first deployment target `/data1/home/sunyiq/kalmannet_tukf20_20260824`, package membership, runtime paths, resource fields, and non-overwrite rules.
- [ ] Build a self-contained runtime closure from the isolated worktree and hash-locked read-only numerical inputs. Reject absolute, parent-traversal, duplicate, symlink, result, and unrelated dirty-worktree members.
- [ ] Make two consecutive builds byte-identical and verify the outer SHA-256 plus every embedded member hash.
- [ ] Implement a smoke program that validates configuration/source hashes, imports, float64/one-thread numerical settings, deterministic truth generation, all four mode masks, one training step per active mode, frozen-group invariance, balance-only test sealing, and projected formal duration.
- [ ] Use one central-processing-unit task and one thread. Slurm scripts must contain no `--mem`, `srun`, or `set -u`; fix all mathematical-library thread variables and write logs only under the new target.
- [ ] Make the formal pipeline require the exact smoke report hash and smoke Slurm completion/exit status before it can start.
- [ ] Add duplicate-submission guards using raw submission output, parsed receipt, stored job identifier, `squeue`, and `sacct`; submission success requires the literal `Submitted batch job` record.
- [ ] Package the formal results, independent verification, figures, configuration, sources, logs, Slurm accounting, submission receipts, embedded manifest, and an external SHA-256 manifest without path traversal or duplicate members.
- [ ] Run `python -m pytest tests/test_tukf20_hpc_migration.py -q` and the full TUKF20 test set.

### Task 7: Execute the gated high-performance-computing workflow

**Files:**
- Modify only in mailbox worktree: `CHANNELS.md`, `payload/kalmannet-tukf20/**`, `inbox/kalmannet-tukf20/cmd.sh`, `inbox/kalmannet-tukf20/seq`, and `outbox/kalmannet-tukf20/**`
- Create only on high-performance computing: `/data1/home/sunyiq/kalmannet_tukf20_20260824/**`
- Retrieve only to: `artifacts/tukf20_hbv_rolling_origin_joint_learning_v1/hpc_retrieved/**`

- [ ] Synchronize the mailbox branch with a full refspec, inspect `CHANNELS.md`, and stop if `kalmannet-tukf20` is already owned by another task.
- [ ] Register the channel and upload the deterministic deployment package and external manifest without staging unrelated channel changes.
- [ ] Deploy through a new temporary directory, verify all member hashes, and atomically move it only if `/data1/home/sunyiq/kalmannet_tukf20_20260824` does not exist.
- [ ] Submit exactly one smoke job. Persist raw `sbatch` output before parsing the job identifier and verify queue/accounting/log/report evidence.
- [ ] Stop without formal submission unless Slurm reports `COMPLETED`, exit code `0:0`, every smoke check is true, the balance gate passes, the independent preflight verification passes, and all evidence binds the same package/configuration/source hashes.
- [ ] Before formal submission, prove no formal raw output, receipt, job identifier, `squeue` record, or `sacct` record already exists for this deployment.
- [ ] Submit exactly one formal paid job and persist its raw output and parsed receipt. Never call `sbatch` again if any submission evidence exists.
- [ ] Monitor approximately every two hours by reading mailbox, `squeue`, `sacct`, exact logs, receipts, and evidence products. Do not duplicate-submit an unchanged or merely pending/running job.
- [ ] For a recoverable technical failure, preserve the failed target and evidence, keep the scientific contract byte-identical, create a new `_retry1` deployment identity and target, obtain one new smoke pass, and only then submit one replacement formal job.
- [ ] If numerical results and independent verification completed but only plotting or packaging failed, recover byte-for-byte from the completed target and rerun only postprocessing; never retrain.
- [ ] Retrieve the result package to the new local retrieval path, verify remote/local byte count and SHA-256, safely extract, verify every embedded member, and cross-check Slurm accounting, logs, configuration, source hashes, registry, independent verification, figures, and manifests.

### Task 8: Report the bounded conclusion

- [ ] Report technical job completion, evidence-chain verification, and scientific comparison outcomes in separate paragraphs.
- [ ] For each primary contrast, report median ratio, paired wins/ties/losses, one-sided exact sign-test probability, and classification.
- [ ] State scientific success only if all three primary contrasts are `CLEAR_BENEFIT`.
- [ ] If any primary contrast fails, state that the joint advantage is not established under this fixed synthetic contract and stop without result-driven retuning.
- [ ] Even on success, limit the claim to this synthetic truth, perturbation design, start distribution, training budget, perfect future forcing, and one-to-three-day horizon. Do not claim unique/true parameter recovery, physical identification of noise, test-period online learning, real-catchment validity, or robustness to forcing forecast error.

