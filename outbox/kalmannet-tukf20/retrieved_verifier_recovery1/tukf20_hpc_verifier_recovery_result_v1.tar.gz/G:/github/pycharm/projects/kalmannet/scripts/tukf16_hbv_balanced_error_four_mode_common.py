"""Common definitions for the balanced-error four-mode rerun."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
import copy
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Any

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for import_root in (ROOT, ROOT / "src"):
    if str(import_root) not in sys.path:
        sys.path.insert(0, str(import_root))

from global_hydrology.models.trainable_hbvlite_ukf_adapter import (  # noqa: E402
    JointTrainableRoutedHBVLiteUKF,
)


DEFAULT_CONFIG = ROOT / "configs" / "tukf16_hbv_balanced_error_four_mode_rerun_v1.json"
EXPERIMENT_ID = "TUKF16_HBV_BALANCED_ERROR_FOUR_MODE_RERUN_V1"
SCHEMA_VERSION = "tukf16_hbv_balanced_error_four_mode_rerun_v1"
TRUTH_SEEDS = (211, 307, 401)
PRIMARY_START_IDS = tuple(f"start_{index:02d}" for index in range(3, 30))
MODE_ORDER = ("all_frozen", "hydrology_only", "filter_only", "joint")
MODE_MASKS = {
    "all_frozen": {"hydrology": False, "filter": False},
    "hydrology_only": {"hydrology": True, "filter": False},
    "filter_only": {"hydrology": False, "filter": True},
    "joint": {"hydrology": True, "filter": True},
}
LEADS = (1, 2, 3)
ANALYSIS_BUDGETS = (32, 96)
QUERY_UPDATES = tuple(range(0, 97, 4))
EXPECTED_STATE_SCALES = np.asarray([8.0, 1.0, 180.0, 25.0, 50.0, 1.0, 1.0, 1.0])
BALANCED_CANDIDATE_ID = "qf_0020__ff_08__hd_0040"
PROCESS_FRACTION = 0.02
FILTER_FACTOR = 8.0
HYDROLOGY_DISTANCE = 0.04
PROCESS_NOISE_BOUNDS = (1e-6, 200.0)
OBSERVATION_RATIO_BOUNDS = (0.0025, 0.8)
PRIMARY_CONTRASTS = {
    "joint_over_all_frozen": ("joint", "all_frozen"),
    "joint_over_hydrology_only": ("joint", "hydrology_only"),
    "joint_over_filter_only": ("joint", "filter_only"),
}


def read_json(path: Path | str) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("refusing to serialize non-finite float")
    return value


def write_new_json(path: Path | str, payload: Mapping[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        jsonable(payload), indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False
    ) + "\n"
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def copy_snapshot(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    return {
        str(key): np.asarray(value).copy()
        if isinstance(value, (np.ndarray, np.generic))
        else copy.deepcopy(value)
        for key, value in snapshot.items()
    }


def _resolve(raw: str | Path) -> Path:
    path = Path(raw)
    return path if path.is_absolute() else ROOT / path


def registered_pairs(
    contract: Mapping[str, Any], *, start_contract: Mapping[str, Any] | None = None
) -> tuple[tuple[int, str], ...]:
    parent = start_contract or read_json(_resolve(contract["parent_configs"]["start_registry"]))
    registry = parent["start_registry"]
    pairs: list[tuple[int, str]] = []
    for seed in TRUTH_SEEDS:
        for start_id in PRIMARY_START_IDS:
            entry = registry[start_id]
            if entry["role"] != "primary_random":
                raise ValueError(f"start is not primary random: {start_id}")
            if int(entry["truth_seed"]) == seed:
                pairs.append((seed, start_id))
    if len(pairs) != 27 or len({start for _, start in pairs}) != 27:
        raise ValueError("expected exactly 27 unique registered start-seed pairs")
    return tuple(pairs)


def _forward_candidate(contract: Mapping[str, Any]) -> dict[str, Any]:
    registry = read_json(_resolve(contract["forward_evidence"]["registry"]))
    matches = [
        row
        for row in registry["candidates"]
        if str(row["candidate_id"]) == BALANCED_CANDIDATE_ID
    ]
    if len(matches) != 1:
        raise ValueError("user-referenced balanced candidate is missing or duplicated")
    return dict(matches[0])


def _validate_forward_evidence(contract: Mapping[str, Any]) -> dict[str, Any]:
    verification = read_json(
        _resolve(contract["forward_evidence"]["independent_verification"])
    )
    seal = read_json(_resolve(contract["forward_evidence"]["zero_query_seal"]))
    if verification.get("status") != "FORMAL_VERIFIED" or not all(
        verification.get("checks", {}).values()
    ):
        raise ValueError("forward gate is not independently verified")
    if seal.get("test_query_count") != 0 or seal.get("optimizer_step_count") != 0:
        raise ValueError("forward evidence is not sealed before test or training")
    candidate = _forward_candidate(contract)
    if not bool(candidate.get("joint_gate_pass")):
        raise ValueError("user-referenced balanced candidate did not pass the forward gate")
    lower, upper = (
        float(value)
        for value in contract["balanced_error_design"][
            "two_sided_influence_ratio_interval"
        ]
    )
    minimum_filter = float(
        contract["balanced_error_design"]["minimum_filter_influence"]
    )
    ratios: list[float] = []
    for window in ("train", "selection"):
        summary = candidate["windows"][window]
        ratios.append(float(summary["influence_ratio"]))
        if float(summary["median_filter_influence"]) < minimum_filter:
            raise ValueError("balanced candidate filter influence is below 20 percent")
        for lead in LEADS:
            ratios.append(float(summary["by_lead"][str(lead)]["influence_ratio"]))
    if not all(lower <= value <= upper for value in ratios):
        raise ValueError("balanced candidate is outside the two-sided comparable range")
    return {
        "candidate_id": candidate["candidate_id"],
        "checked_ratio_count": len(ratios),
        "minimum_ratio": min(ratios),
        "maximum_ratio": max(ratios),
    }


def validate_contract(
    contract: Mapping[str, Any], *, verify_files: bool = True
) -> dict[str, Any]:
    if contract.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unexpected TUKF16 schema version")
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("unexpected TUKF16 experiment identifier")
    if not bool(contract.get("authorization", {}).get("user_authorized_rerun")):
        raise PermissionError("the balanced-error rerun requires user authorization")
    if not bool(contract.get("authorization", {}).get("formal_training_authorized")):
        raise PermissionError("formal training is not authorized")
    design = contract["balanced_error_design"]
    expected_design = {
        "forward_candidate_id": BALANCED_CANDIDATE_ID,
        "process_standard_deviation_fraction": PROCESS_FRACTION,
        "filter_perturbation_factor": FILTER_FACTOR,
        "filter_perturbation_low_multiplier": 1.0 / FILTER_FACTOR,
        "filter_perturbation_high_multiplier": FILTER_FACTOR,
        "hydrology_coordinate_distance": HYDROLOGY_DISTANCE,
    }
    for key, expected in expected_design.items():
        if design.get(key) != expected:
            raise ValueError("design differs from the user-referenced balanced candidate")
    if tuple(int(value) for value in contract["truth_seeds"]) != TRUTH_SEEDS:
        raise ValueError("truth seed registry changed")
    if tuple(str(value) for value in contract["primary_start_ids"]) != PRIMARY_START_IDS:
        raise ValueError("primary start registry changed")
    if tuple(str(value) for value in contract["mode_order"]) != MODE_ORDER:
        raise ValueError("mode order changed")
    masks = {
        str(mode): {
            "hydrology": bool(values["hydrology"]),
            "filter": bool(values["filter"]),
        }
        for mode, values in contract["mode_masks"].items()
    }
    if masks != MODE_MASKS:
        raise ValueError("mode masks changed")
    if tuple(int(value) for value in contract["selection"]["analysis_budgets"]) != ANALYSIS_BUDGETS:
        raise ValueError("analysis budgets changed")
    if tuple(int(value) for value in contract["selection"]["query_updates"]) != QUERY_UPDATES:
        raise ValueError("selection query registry changed")
    segments = contract["segments"]
    if [segments["train_target_start"], segments["train_target_end_exclusive"]] != [28, 108]:
        raise ValueError("training segment changed")
    if [segments["selection_target_start"], segments["selection_target_end_exclusive"]] != [108, 148]:
        raise ValueError("selection segment changed")
    if [segments["test_target_start"], segments["test_target_end_exclusive"]] != [148, 192]:
        raise ValueError("test segment changed")
    start_contract = read_json(_resolve(contract["parent_configs"]["start_registry"]))
    pairs = registered_pairs(contract, start_contract=start_contract)
    truth_contract = read_json(_resolve(contract["parent_configs"]["truth_generator"]))
    initial_state = np.asarray(truth_contract["truth"]["initial_state"], dtype=np.float64)
    scales = np.maximum(np.abs(initial_state), 1.0)
    if not np.array_equal(scales, EXPECTED_STATE_SCALES) or not np.array_equal(
        scales, np.asarray(contract["expected_state_scales"], dtype=np.float64)
    ):
        raise ValueError("state scales changed")
    forward = _validate_forward_evidence(contract)
    if verify_files:
        for raw_path, expected in contract["input_sha256"].items():
            actual = sha256_file(_resolve(raw_path))
            if actual != str(expected):
                raise ValueError(f"input SHA-256 mismatch: {raw_path}")
    return {
        "registered_pair_count": len(pairs),
        "mode_cell_count": len(pairs) * len(MODE_ORDER),
        "forward_evidence": forward,
    }


def load_contract(path: Path | str = DEFAULT_CONFIG) -> dict[str, Any]:
    contract = read_json(path)
    validate_contract(contract)
    return contract


def truth_process_variances(parent_contract: Mapping[str, Any]) -> np.ndarray:
    initial = np.asarray(parent_contract["truth"]["initial_state"], dtype=np.float64)
    scales = np.maximum(np.abs(initial), 1.0)
    return np.square(scales * PROCESS_FRACTION)


def build_start_values(
    parent_contract: Mapping[str, Any],
    start_contract: Mapping[str, Any],
    start_id: str,
) -> dict[str, Any]:
    entry = start_contract["start_registry"][start_id]
    truth = parent_contract["truth"]
    names = truth["trainable_hydrology_names"]
    parameters = np.asarray(truth["hydrology_parameters"], dtype=np.float64)
    lower = np.asarray([truth["hydrology_v5_bounds"][name][0] for name in names])
    upper = np.asarray([truth["hydrology_v5_bounds"][name][1] for name in names])
    truth_coordinate = (parameters[:12] - lower) / (upper - lower)
    coordinate = truth_coordinate + HYDROLOGY_DISTANCE * np.asarray(
        entry["hydrology_signs"], dtype=np.float64
    )
    if np.any(coordinate <= 0.0) or np.any(coordinate >= 1.0):
        raise ValueError(f"updated hydrology start lies outside strict bounds: {start_id}")
    hydrology = np.concatenate(
        (lower + coordinate * (upper - lower), parameters[12:13])
    )
    truth_process = truth_process_variances(parent_contract)
    process_multiplier = np.asarray(
        [1.0 / FILTER_FACTOR if float(value) < 1.0 else FILTER_FACTOR for value in entry["process_multipliers"]],
        dtype=np.float64,
    )
    process = truth_process * process_multiplier
    observation = float(truth["observation_residual_ratio"]) * (
        1.0 / FILTER_FACTOR
        if float(entry["observation_multiplier"]) < 1.0
        else FILTER_FACTOR
    )
    return {
        "hydrology_parameters": np.ascontiguousarray(hydrology),
        "process_variances": np.ascontiguousarray(process),
        "observation_ratio": observation,
        "truth_process_variances": truth_process,
    }


def build_model(
    contract: Mapping[str, Any],
    parent_contract: Mapping[str, Any],
    start_contract: Mapping[str, Any],
    start_id: str,
    *,
    dtype: torch.dtype = torch.float64,
    device: torch.device | str = torch.device("cpu"),
) -> JointTrainableRoutedHBVLiteUKF:
    if start_id not in PRIMARY_START_IDS:
        raise ValueError(f"unknown primary start: {start_id}")
    values = build_start_values(parent_contract, start_contract, start_id)
    return JointTrainableRoutedHBVLiteUKF(
        torch.as_tensor(values["hydrology_parameters"], dtype=dtype, device=device).reshape(1, -1),
        torch.as_tensor(parent_contract["truth"]["routing_weights"], dtype=dtype, device=device).reshape(1, -1),
        initial_process_diagonal=torch.as_tensor(values["process_variances"], dtype=dtype, device=device),
        initial_observation_ratio=float(values["observation_ratio"]),
        process_noise_bounds=PROCESS_NOISE_BOUNDS,
        observation_ratio_bounds=OBSERVATION_RATIO_BOUNDS,
        clamp_storage=True,
        signed_routing_memory=False,
        dtype=dtype,
        device=torch.device(device),
    )


def configure_mode_(model: JointTrainableRoutedHBVLiteUKF, mode: str) -> None:
    if mode not in MODE_MASKS:
        raise ValueError(f"unknown mode: {mode}")
    mask = MODE_MASKS[mode]
    for parameter in (model.hydrology_coordinates,):
        parameter.grad = None
        parameter.requires_grad_(mask["hydrology"])
    for parameter in (model.log_process_diagonal, model.log_observation_ratio):
        parameter.grad = None
        parameter.requires_grad_(mask["filter"])


def build_optimizer(
    model: JointTrainableRoutedHBVLiteUKF,
    mode: str,
    contract: Mapping[str, Any],
) -> torch.optim.Adam | None:
    mask = MODE_MASKS[mode]
    groups: list[dict[str, Any]] = []
    if mask["hydrology"]:
        groups.append(
            {
                "params": [model.hydrology_coordinates],
                "lr": float(contract["optimizer"]["hydrology_learning_rate"]),
                "group_name": "hydrology",
            }
        )
    if mask["filter"]:
        groups.append(
            {
                "params": [model.log_process_diagonal, model.log_observation_ratio],
                "lr": float(contract["optimizer"]["filter_learning_rate"]),
                "group_name": "filter",
            }
        )
    if not groups:
        return None
    return torch.optim.Adam(
        groups,
        betas=tuple(float(value) for value in contract["optimizer"]["betas"]),
        eps=float(contract["optimizer"]["epsilon"]),
        weight_decay=float(contract["optimizer"]["weight_decay"]),
        amsgrad=bool(contract["optimizer"]["amsgrad"]),
    )


def clip_active_gradients_(
    model: JointTrainableRoutedHBVLiteUKF,
    mode: str,
    contract: Mapping[str, Any],
) -> dict[str, float]:
    mask = MODE_MASKS[mode]
    groups = {
        "hydrology": [model.hydrology_coordinates],
        "filter": [model.log_process_diagonal, model.log_observation_ratio],
    }
    result: dict[str, float] = {}
    limit = float(contract["optimizer"]["group_gradient_norm"])
    for name, parameters in groups.items():
        if not mask[name]:
            if any(parameter.grad is not None for parameter in parameters):
                raise RuntimeError(f"frozen {name} group received a gradient")
            continue
        if any(parameter.grad is None or not bool(torch.isfinite(parameter.grad).all()) for parameter in parameters):
            raise FloatingPointError(f"active {name} gradient is missing or non-finite")
        norm = float(torch.nn.utils.clip_grad_norm_(parameters, limit))
        if not math.isfinite(norm):
            raise FloatingPointError(f"active {name} gradient norm is non-finite")
        result[name] = norm
    return result


def assert_frozen_groups_unchanged(
    before: Mapping[str, Any], after: Mapping[str, Any], mode: str
) -> None:
    mask = MODE_MASKS[mode]
    keys = {
        "hydrology": ("hydrology", "physical_parameters"),
        "filter": ("log_process", "log_observation", "process_diagonal", "observation_ratio"),
    }
    for name, group_keys in keys.items():
        if mask[name]:
            continue
        for key in group_keys:
            if not np.array_equal(np.asarray(before[key]), np.asarray(after[key])):
                raise RuntimeError(f"frozen {name} value changed: {key}")
    for key in ("lag_time", "state_dimension"):
        if not np.array_equal(np.asarray(before[key]), np.asarray(after[key])):
            raise RuntimeError(f"fixed model structure changed: {key}")


def select_budget_checkpoint(
    selection_rows: Sequence[Mapping[str, Any]], budget: int
) -> dict[str, Any]:
    allowed = [
        {"update": int(row["update"]), "selection_loss": float(row["selection_loss"])}
        for row in selection_rows
        if int(row["update"]) <= int(budget)
    ]
    expected = tuple(range(0, int(budget) + 1, 4))
    if tuple(row["update"] for row in allowed) != expected:
        raise ValueError(f"selection queries are incomplete for budget {budget}")
    if not all(math.isfinite(row["selection_loss"]) and row["selection_loss"] > 0.0 for row in allowed):
        raise ValueError("selection losses must be finite and positive")
    return min(allowed, key=lambda row: (row["selection_loss"], row["update"]))


def _binomial_tail_fraction(wins: int, replicates: int) -> Fraction:
    numerator = sum(math.comb(replicates, value) for value in range(wins, replicates + 1))
    return Fraction(numerator, 2**replicates)


def aggregate_budget(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any], budget: int
) -> dict[str, Any]:
    selected = [row for row in rows if int(row["analysis_budget"]) == int(budget)]
    indexed: dict[tuple[int, str, str], Mapping[str, Any]] = {}
    for row in selected:
        key = (int(row["truth_seed"]), str(row["start_id"]), str(row["mode"]))
        if key in indexed:
            raise ValueError(f"duplicate test cell: {key}")
        indexed[key] = row
    expected = {
        (seed, start_id, mode)
        for seed, start_id in registered_pairs(contract)
        for mode in MODE_ORDER
    }
    if set(indexed) != expected:
        raise ValueError("test cell product is incomplete")
    primary: dict[str, Any] = {}
    for name, (numerator, denominator) in PRIMARY_CONTRASTS.items():
        ratios = []
        per_start = []
        for seed, start_id in registered_pairs(contract):
            numerator_value = float(indexed[(seed, start_id, numerator)]["test_mean_mse"])
            denominator_value = float(indexed[(seed, start_id, denominator)]["test_mean_mse"])
            if not (numerator_value > 0.0 and denominator_value > 0.0):
                raise ValueError("test errors must be positive")
            ratio = numerator_value / denominator_value
            ratios.append(ratio)
            per_start.append({"truth_seed": seed, "start_id": start_id, "ratio": ratio})
        wins = sum(value < 1.0 for value in ratios)
        tail = _binomial_tail_fraction(wins, 27)
        median = float(np.median(ratios))
        primary[name] = {
            "numerator": numerator,
            "denominator": denominator,
            "per_start_ratios": per_start,
            "median_ratio": median,
            "ratio_range": [min(ratios), max(ratios)],
            "wins": wins,
            "win_fraction": wins / 27.0,
            "sign_test_exact_p_at_least_wins": float(tail),
            "sign_test_exact_p_numerator": tail.numerator,
            "sign_test_exact_p_denominator": tail.denominator,
            "ratio_gate_pass": median < float(contract["gates"]["primary_median_ratio_max_exclusive"]),
            "sign_gate_pass": wins >= int(contract["gates"]["sign_test_minimum_wins"]),
        }
        by_lead: dict[str, Any] = {}
        for lead in ("1", "2", "3"):
            lead_ratios = []
            for seed, start_id in registered_pairs(contract):
                lead_ratios.append(
                    float(indexed[(seed, start_id, numerator)]["test_mse_by_lead"][lead])
                    / float(indexed[(seed, start_id, denominator)]["test_mse_by_lead"][lead])
                )
            lead_wins = sum(value < 1.0 for value in lead_ratios)
            lead_tail = _binomial_tail_fraction(lead_wins, 27)
            by_lead[lead] = {
                "median_ratio": float(np.median(lead_ratios)),
                "ratio_range": [min(lead_ratios), max(lead_ratios)],
                "wins": lead_wins,
                "win_fraction": lead_wins / 27.0,
                "sign_test_exact_p_at_least_wins": float(lead_tail),
            }
        primary[name]["by_lead"] = by_lead
    classification = "FORECAST_GO" if all(
        row["ratio_gate_pass"] and row["sign_gate_pass"] for row in primary.values()
    ) else "FORECAST_HOLD"
    return {
        "analysis_budget": int(budget),
        "independent_unit": "start",
        "independent_unit_count": 27,
        "primary": primary,
        "classification": classification,
        "valid_comparison": True,
    }
