# TUKF20 Verifier Recovery Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Recover independent technical verification, figures, and a result package from Slurm job 210748 without rerunning training or changing the frozen scientific experiment.

**Architecture:** Preserve `/data1/home/sunyiq/kalmannet_tukf20_20260824` as immutable failed evidence and copy it into the new target `/data1/home/sunyiq/kalmannet_tukf20_20260824_verifier_recovery1`. Run the corrected verifier under a new filename so the original scientific source closure remains hash-identical, then plot and validate only in the copied target. Use separate Slurm jobs for verification recovery and post-accounting packaging so packaging cannot start until the recovery job is recorded as `COMPLETED` with exit code `0:0`.

**Tech Stack:** Python 3.11, NumPy, PyTorch, pytest, Slurm, deterministic tar/gzip packaging, Git mailbox channel `kalmannet-tukf20`.

## Global Constraints

- The original local repository and `/data1/home/sunyiq/kalmannet_tukf20_20260824` are read-only evidence.
- The scientific configuration, 27 accepted seed/start pairs, four modes, optimizer schedule, test origins, success gates, and stopping rules must not change.
- Slurm job 210748 remains the only formal paid experiment job; no smoke or formal job may be resubmitted.
- The recovery is verifier/postprocessing only and must never import or call the formal runner or mode trainer.
- Failed verification evidence must be retained under the recovery target before a new verification file is created.
- Every target, submission claim, completion record, log, archive, and manifest must be created with non-overwrite semantics.
- Technical verification and scientific classification must be reported separately.
- No implementation-worktree commit, cleanup, publication, or modification of the original HPC repository is allowed.

---

### Task 1: Correct persisted-array selection

**Files:**
- Modify: `scripts/verify_tukf20_hbv_rolling_origin_joint_learning.py`
- Modify: `tests/test_verify_tukf20_hbv_rolling_origin_joint_learning.py`

**Interfaces:**
- Consumes: `numerical_reference._stream_reconstruct(...) -> dict[str, Any]`.
- Produces: `_persisted_readout_arrays(reconstructed: Mapping[str, Any]) -> dict[str, np.ndarray]`.

- [x] **Step 1: Write a regression test**

  Construct a reconstruction containing the 15 arrays written by the formal runner plus the metric-only arrays `per_state_rmse` and `prior_per_state_rmse`; require that only the 15 persisted arrays are selected.

- [x] **Step 2: Run the test against the faulty implementation**

  Confirm that the previous `isinstance(value, np.ndarray)` selection includes the two metric-only arrays and therefore cannot match `arrays.npz`.

- [x] **Step 3: Implement the minimal correction**

  Add the explicit `PERSISTED_READOUT_ARRAY_NAMES` set and select exactly those arrays, raising if any required reconstructed array is absent.

- [x] **Step 4: Run the TUKF20 test suite**

  Run: `python -m pytest -q tests/test_tukf20_hbv_rolling_origin_joint_learning.py tests/test_tukf20_hbv_rolling_origin_runner.py tests/test_tukf20_hpc_migration.py tests/test_verify_tukf20_hbv_rolling_origin_joint_learning.py`

  Expected: `74 passed, 1 skipped`.

### Task 2: Build a verifier-only recovery entrypoint

**Files:**
- Create: `configs/tukf20_hpc_verifier_recovery_v1.json`
- Create: `scripts/recover_tukf20_hpc_verifier_postprocessing.py`
- Modify: `tests/test_tukf20_hpc_migration.py`

**Interfaces:**
- Consumes: immutable source hashes, Slurm job 210748 accounting, copied TUKF20 result tree, corrected verifier under an alternate filename.
- Produces: `run_verifier_recovery(contract_path: Path, recovery_contract_path: Path) -> dict[str, Any]` and `verifier_recovery_outputs_complete.json`.

- [ ] **Step 1: Write tests for scope and source pins**

  Require the recovery contract to pin job 210748, original bundle SHA-256 `721fa666319cc448e901515d066bb217560c87ec8edd19e5cbb2300269074f76`, source registry/manifest/failed-verification hashes, and the new target. Assert that the recovery entrypoint contains no call to the formal runner or mode trainer.

- [ ] **Step 2: Implement source-evidence validation**

  Verify source accounting is `FAILED`/`1:0`, verify every pinned source hash, verify the original standard verifier hash, and verify the current root is the registered new recovery target.

- [ ] **Step 3: Preserve failed evidence and rerun only verification**

  Move the copied failed `independent_verification.json` to the recovery evidence directory, run `verify_tukf20_hbv_rolling_origin_joint_learning_recovery1.py --stage formal`, and assert all verification checks are true.

- [ ] **Step 4: Plot and validate outputs**

  Run the existing plotter, call `validate_formal_outputs`, and write an awaiting-accounting completion record containing all hashes, counts, the repaired-verifier hash, and the scientific classification boundary.

- [ ] **Step 5: Run focused tests**

  Run: `python -m pytest -q tests/test_tukf20_hpc_migration.py tests/test_verify_tukf20_hbv_rolling_origin_joint_learning.py`

### Task 3: Deploy and execute one recovery job

**Files:**
- Create: `scripts/build_tukf20_hpc_verifier_recovery_bundle.py`
- Create: `hpc/tukf20_hbv_rolling_origin_joint_learning/submit_verifier_recovery_cpu1.slurm`
- Modify: `tests/test_tukf20_hpc_migration.py`

**Interfaces:**
- Consumes: the recovery contract, recovery entrypoint, corrected alternate verifier, and immutable source target.
- Produces: a deterministic recovery deployment archive and exactly one verifier-recovery Slurm job identifier.

- [ ] **Step 1: Test deterministic bundle membership**

  Build twice and require identical SHA-256 values and the exact recovery-only member set.

- [ ] **Step 2: Implement the recovery bundle builder**

  Reuse the existing safe deterministic archive functions and emit an embedded member-hash manifest plus an external SHA-256 manifest.

- [ ] **Step 3: Implement the Slurm script**

  Request `hcpu48y`, one task, one central processing unit, no custom memory, no `srun`, and no `set -u`. Copy the 20-megabyte source target to a unique staging directory, add recovery files under new filenames, atomically rename it to the recovery target, then execute only the recovery entrypoint.

- [ ] **Step 4: Submit through the Git mailbox with a permanent claim**

  Store raw `sbatch` output before parsing, require the literal `Submitted batch job <number>`, write a receipt and queue snapshot, and refuse any second submission if the claim or receipt exists.

- [ ] **Step 5: Verify terminal accounting**

  Require the recovery job to reach `COMPLETED`/`0:0`, preserve stdout/stderr and `sacct`, and create `verifier_recovery_slurm_completion.json` only after that accounting is observed.

### Task 4: Package and retrieve verified evidence after accounting

**Files:**
- Create: `scripts/package_tukf20_hpc_verifier_recovery.py`
- Create: `hpc/tukf20_hbv_rolling_origin_joint_learning/submit_verifier_recovery_package_cpu1.slurm`
- Modify: `tests/test_tukf20_hpc_migration.py`

**Interfaces:**
- Consumes: recovered outputs, `verifier_recovery_slurm_completion.json`, source failure evidence, recovery logs, and member hashes.
- Produces: one deterministic recovery result archive, its manifest, and exactly one packaging Slurm job identifier.

- [ ] **Step 1: Test the post-accounting gate**

  Require packaging to reject missing accounting, any state other than `COMPLETED`, any exit code other than `0:0`, or a job identifier different from the recovery submission receipt.

- [ ] **Step 2: Implement deterministic evidence packaging**

  Include the original source bundle manifest, source job logs and failed verification, untouched scientific outputs, recovered verification, figures, recovery source files, submission evidence, and accounting evidence. Emit member hashes and the explicit technical/scientific boundary.

- [ ] **Step 3: Submit one packaging job**

  Use the same permanent-claim and raw-output-before-parsing safeguards; the script must contain no training or scientific verification command.

- [ ] **Step 4: Verify packaging accounting and retrieve through the mailbox**

  Require `COMPLETED`/`0:0`, copy the archive and manifest to `outbox/kalmannet-tukf20/retrieved_recovery1`, verify byte count and SHA-256 before and after the copy, and commit only those exact binary evidence files.

- [ ] **Step 5: Perform the final independent audit**

  Extract locally into a new audit directory; verify archive safety, every member hash, all 20 independent checks, 108 readouts, 13,608 clean errors, all figure hashes, both Slurm completion records, and the three preregistered primary contrasts before reporting the scientific classification.

## Self-Review

- Spec coverage: the plan preserves both original local/HPC evidence, forbids scientific reruns, separates recovery and post-accounting packaging, and includes mailbox retrieval and independent audit.
- Placeholder scan: no deferred implementation placeholders remain.
- Type consistency: recovery entrypoint, completion record, package gate, and archive interfaces use distinct names and stages.
