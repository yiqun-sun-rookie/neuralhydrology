"""Package recovered TUKF20 evidence after successful recovery accounting."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import traceback
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import build_tukf20_hpc_bundle as bundle_builder  # noqa: E402
from scripts import recover_tukf20_hpc_verifier_postprocessing as recovery  # noqa: E402
from scripts import run_tukf20_hpc_formal_pipeline as formal_pipeline  # noqa: E402
from scripts import tukf20_hbv_rolling_origin_joint_learning_common as scientific  # noqa: E402
from scripts import tukf20_hpc_deployment_common as deployment_common  # noqa: E402


def _read_json(path: Path | str) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"expected a JSON object: {path}")
    return value


def validate_recovery_slurm_completion(
    recovery_contract: Mapping[str, Any], completion_path: Path
) -> dict[str, Any]:
    completion = _read_json(completion_path)
    recovery_specification = recovery_contract["recovery"]
    outputs_path = ROOT / str(recovery_specification["outputs_complete_record"])
    outputs = _read_json(outputs_path)
    job_id = int(completion.get("recovery_slurm_job_id", -1))
    evidence = completion.get("evidence", {})
    sacct_path = ROOT / str(evidence.get("sacct_path", ""))
    stdout_path = ROOT / str(evidence.get("stdout_path", ""))
    stderr_path = ROOT / str(evidence.get("stderr_path", ""))
    checks = {
        "schema": completion.get("schema_version")
        == "tukf20_hpc_verifier_recovery_slurm_completion_v1",
        "status": completion.get("status")
        == "VERIFIER_RECOVERY_SLURM_COMPLETED",
        "identity": completion.get("recovery_id")
        == recovery_contract["recovery_id"]
        and completion.get("scientific_experiment_id") == scientific.EXPERIMENT_ID,
        "job_identity": str(outputs.get("recovery_slurm_job_id")) == str(job_id),
        "completed_accounting": completion.get("slurm_state") == "COMPLETED"
        and completion.get("slurm_exit_code") == "0:0",
        "outputs_status": outputs.get("status")
        == "VERIFIER_RECOVERY_OUTPUTS_VERIFIED_AWAITING_SLURM_ACCOUNTING",
        "outputs_hash": outputs_path.is_file()
        and deployment_common.sha256_file(outputs_path)
        == completion.get("outputs_complete_sha256"),
        "sacct_hash": sacct_path.is_file()
        and deployment_common.sha256_file(sacct_path)
        == evidence.get("sacct_sha256"),
        "stdout_hash": stdout_path.is_file()
        and deployment_common.sha256_file(stdout_path)
        == evidence.get("stdout_sha256"),
        "stderr_hash": stderr_path.is_file()
        and deployment_common.sha256_file(stderr_path)
        == evidence.get("stderr_sha256"),
        "no_training_rerun": outputs.get("formal_training_rerun") is False,
        "scientific_contract_unchanged": outputs.get("scientific_contract_changed")
        is False,
    }
    if not all(checks.values()):
        raise PermissionError(f"recovery Slurm completion gate failed: {checks}")
    return {
        "checks": checks,
        "completion": completion,
        "outputs": outputs,
        "job_id": job_id,
    }


def _package_members(
    archive_path: Path, manifest_path: Path, packaging_job_id: str
) -> dict[str, Path]:
    excluded = {
        archive_path.resolve(),
        manifest_path.resolve(),
        (ROOT / f"logs/verifier-recovery-package-{packaging_job_id}.out").resolve(),
        (ROOT / f"logs/verifier-recovery-package-{packaging_job_id}.err").resolve(),
    }
    members: dict[str, Path] = {}
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.resolve() in excluded:
            continue
        relative = path.relative_to(ROOT).as_posix()
        bundle_builder.safe_member_name(relative)
        if relative in members:
            raise ValueError(f"duplicate recovery package member: {relative}")
        members[relative] = path
    if not members:
        raise ValueError("recovery package has no members")
    return members


def package_recovered_results(
    *, recovery_contract_path: Path, recovery_bundle_manifest_path: Path
) -> dict[str, Any]:
    contract = recovery.load_recovery_contract(recovery_contract_path)
    recovery_specification = contract["recovery"]
    deployment_root = ROOT / str(recovery_specification["deployment_evidence_root"])
    status_root = deployment_root / "status"
    started_path = status_root / "packaging_started.json"
    outputs_path = status_root / "packaging_outputs_complete.json"
    failure_path = status_root / "packaging_failure.json"
    completion_path = ROOT / str(recovery_specification["slurm_completion_record"])
    archive_path = ROOT / str(recovery_specification["result_archive"])
    manifest_path = ROOT / str(recovery_specification["result_archive_manifest"])
    if any(
        path.exists()
        for path in (started_path, outputs_path, failure_path, archive_path, manifest_path)
    ):
        raise FileExistsError("refusing to replace verifier-recovery package evidence")
    packaging_job_id = str(os.environ.get("SLURM_JOB_ID", ""))
    if not packaging_job_id:
        raise PermissionError("packaging requires a Slurm allocation")

    try:
        bundle_validation = recovery.verify_recovery_bundle(
            contract, recovery_bundle_manifest_path
        )
        completion_validation = validate_recovery_slurm_completion(
            contract, completion_path
        )
        source_validation = recovery.verify_source_evidence(contract)
        scientific_config = ROOT / recovery.SCIENTIFIC_CONFIG_RELATIVE
        scientific_contract = scientific.load_contract(scientific_config)
        deployment = _read_json(ROOT / recovery.DEPLOYMENT_CONFIG_RELATIVE)
        formal_validation = formal_pipeline.validate_formal_outputs(
            deployment, scientific_contract, scientific=scientific
        )
        scientific.write_new_json(
            started_path,
            {
                "schema_version": "tukf20_hpc_verifier_recovery_packaging_start_v1",
                "recovery_id": contract["recovery_id"],
                "scientific_experiment_id": scientific.EXPERIMENT_ID,
                "source_formal_job_id": contract["source"]["formal_job_id"],
                "recovery_slurm_job_id": completion_validation["job_id"],
                "packaging_slurm_job_id": packaging_job_id,
                "recovery_bundle_sha256": bundle_validation["archive_sha256"],
                "started_at_utc": datetime.now(timezone.utc).isoformat(),
                "formal_training_rerun": False,
                "independent_verification_rerun_during_packaging": False,
            },
        )
        members = _package_members(archive_path, manifest_path, packaging_job_id)
        member_hashes = {
            name: deployment_common.sha256_file(path)
            for name, path in members.items()
        }
        payload = {
            "schema_version": "tukf20_hpc_verifier_recovery_result_payload_v1",
            "recovery_id": contract["recovery_id"],
            "scientific_experiment_id": scientific.EXPERIMENT_ID,
            "source_formal_job_id": contract["source"]["formal_job_id"],
            "recovery_slurm_job_id": completion_validation["job_id"],
            "packaging_slurm_job_id": packaging_job_id,
            "original_formal_bundle_sha256": contract["source"]["bundle_sha256"],
            "recovery_bundle_sha256": bundle_validation["archive_sha256"],
            "validation": {
                key: value
                for key, value in formal_validation.items()
                if key not in {"result_root", "figure_root"}
            },
            "scientific_classification": completion_validation["outputs"][
                "scientific_classification"
            ],
            "members": member_hashes,
            "formal_training_rerun": False,
            "technical_verification_is_not_scientific_success": True,
        }
        payload_name = "verifier_recovery_result_payload_manifest.json"
        payload_bytes = deployment_common.canonical_json_bytes(payload)
        bundle_builder.write_deterministic_archive(
            archive_path,
            members,
            virtual_members={payload_name: payload_bytes},
        )
        external = {
            "schema_version": "tukf20_hpc_verifier_recovery_result_bundle_manifest_v1",
            "recovery_id": contract["recovery_id"],
            "scientific_experiment_id": scientific.EXPERIMENT_ID,
            "source_formal_job_id": contract["source"]["formal_job_id"],
            "recovery_slurm_job_id": completion_validation["job_id"],
            "packaging_slurm_job_id": packaging_job_id,
            "archive_name": archive_path.name,
            "archive_sha256": deployment_common.sha256_file(archive_path),
            "archive_bytes": archive_path.stat().st_size,
            "payload_manifest_name": payload_name,
            "payload_manifest_sha256": deployment_common.sha256_bytes(payload_bytes),
            "member_count": len(member_hashes),
            "members": member_hashes,
            "formal_training_rerun": False,
            "technical_verification_is_not_scientific_success": True,
        }
        scientific.write_new_json(manifest_path, external)
        bundle_builder.verify_archive_against_manifest(archive_path, external)
        report = {
            "schema_version": "tukf20_hpc_verifier_recovery_packaging_outputs_v1",
            "recovery_id": contract["recovery_id"],
            "scientific_experiment_id": scientific.EXPERIMENT_ID,
            "status": "VERIFIER_RECOVERY_PACKAGE_COMPLETE_AWAITING_SLURM_ACCOUNTING",
            "source_formal_job_id": contract["source"]["formal_job_id"],
            "recovery_slurm_job_id": completion_validation["job_id"],
            "packaging_slurm_job_id": packaging_job_id,
            "source_validation_checks": source_validation["checks"],
            "recovery_completion_checks": completion_validation["checks"],
            "formal_output_validation": {
                key: value
                for key, value in formal_validation.items()
                if key not in {"result_root", "figure_root"}
            },
            "archive": {
                "path": archive_path.relative_to(ROOT).as_posix(),
                "sha256": external["archive_sha256"],
                "bytes": external["archive_bytes"],
                "member_count": external["member_count"],
            },
            "manifest": {
                "path": manifest_path.relative_to(ROOT).as_posix(),
                "sha256": deployment_common.sha256_file(manifest_path),
                "bytes": manifest_path.stat().st_size,
            },
            "scientific_classification": completion_validation["outputs"][
                "scientific_classification"
            ],
            "formal_training_rerun": False,
            "independent_verification_rerun_during_packaging": False,
            "technical_verification_is_not_scientific_success": True,
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        scientific.write_new_json(outputs_path, report)
        return report
    except Exception as error:
        if not failure_path.exists():
            scientific.write_new_json(
                failure_path,
                {
                    "schema_version": "tukf20_hpc_verifier_recovery_packaging_failure_v1",
                    "recovery_id": contract["recovery_id"],
                    "scientific_experiment_id": scientific.EXPERIMENT_ID,
                    "status": "VERIFIER_RECOVERY_PACKAGING_FAILED",
                    "packaging_slurm_job_id": packaging_job_id,
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    "formal_training_rerun": False,
                    "failed_at_utc": datetime.now(timezone.utc).isoformat(),
                },
            )
        raise


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recovery-config", type=Path, required=True)
    parser.add_argument("--recovery-bundle-manifest", type=Path, required=True)
    parser.add_argument("--confirm-post-accounting-package", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    if not args.confirm_post_accounting_package:
        raise PermissionError("explicit post-accounting packaging confirmation is required")
    report = package_recovered_results(
        recovery_contract_path=args.recovery_config.resolve(),
        recovery_bundle_manifest_path=args.recovery_bundle_manifest.resolve(),
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "source_formal_job_id": report["source_formal_job_id"],
                "recovery_slurm_job_id": report["recovery_slurm_job_id"],
                "packaging_slurm_job_id": report["packaging_slurm_job_id"],
                "archive": report["archive"],
                "technical_verification_is_not_scientific_success": True,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
