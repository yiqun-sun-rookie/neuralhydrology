"""Build the deterministic TUKF20 verifier-recovery deployment archive."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import build_tukf20_hpc_bundle as archive_tools  # noqa: E402
from scripts import tukf20_hpc_deployment_common as deployment_common  # noqa: E402


RECOVERY_ID = "TUKF20_HPC_VERIFIER_RECOVERY_V1"
SCIENTIFIC_EXPERIMENT_ID = "TUKF20_HBV_ROLLING_ORIGIN_JOINT_LEARNING_V1"
DEFAULT_OUTPUT_ROOT = ROOT / "artifacts/tukf20_hpc_verifier_recovery_v1"
ARCHIVE_NAME = "tukf20_hpc_verifier_recovery_payload_v1.tar.gz"
MANIFEST_NAME = "bundle_manifest.sha256.json"
PAYLOAD_MANIFEST_NAME = "recovery_payload_manifest.json"

APPLICATION_FILES = (
    "configs/tukf20_hpc_verifier_recovery_v1.json",
    "docs/superpowers/plans/2026-08-24-tukf20-verifier-recovery.md",
    "scripts/build_tukf20_hpc_verifier_recovery_bundle.py",
    "scripts/recover_tukf20_hpc_verifier_postprocessing.py",
    "scripts/package_tukf20_hpc_verifier_recovery.py",
    "hpc/tukf20_hbv_rolling_origin_joint_learning/submit_verifier_recovery_cpu1.slurm",
    "hpc/tukf20_hbv_rolling_origin_joint_learning/submit_verifier_recovery_package_cpu1.slurm",
)
CORRECTED_VERIFIER_MEMBER = (
    "scripts/verify_tukf20_hbv_rolling_origin_joint_learning_recovery1.py"
)
CORRECTED_VERIFIER_SOURCE = (
    ROOT / "scripts/verify_tukf20_hbv_rolling_origin_joint_learning.py"
)


def payload_members() -> dict[str, Path]:
    members = {name: ROOT / name for name in APPLICATION_FILES}
    members[CORRECTED_VERIFIER_MEMBER] = CORRECTED_VERIFIER_SOURCE
    missing = [name for name, path in members.items() if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"verifier-recovery source is incomplete: {missing}")
    for name, path in members.items():
        archive_tools.validate_source_file(name, path)
    return dict(sorted((name, path.resolve()) for name, path in members.items()))


def build_bundle(output_root: Path | str | None = None) -> dict[str, Any]:
    output = Path(output_root) if output_root is not None else DEFAULT_OUTPUT_ROOT
    output.mkdir(parents=True, exist_ok=True)
    archive_path = output / ARCHIVE_NAME
    manifest_path = output / MANIFEST_NAME
    if archive_path.exists() or manifest_path.exists():
        raise FileExistsError("refusing to replace verifier-recovery deployment bundle")
    members = payload_members()
    member_hashes = {
        name: deployment_common.sha256_file(path) for name, path in members.items()
    }
    recovery_contract_path = ROOT / "configs/tukf20_hpc_verifier_recovery_v1.json"
    recovery_contract = json.loads(recovery_contract_path.read_text(encoding="utf-8"))
    payload = {
        "schema_version": "tukf20_hpc_verifier_recovery_payload_v1",
        "recovery_id": RECOVERY_ID,
        "scientific_experiment_id": SCIENTIFIC_EXPERIMENT_ID,
        "recovery_contract_sha256": deployment_common.sha256_file(
            recovery_contract_path
        ),
        "source_formal_job_id": recovery_contract["source"]["formal_job_id"],
        "source_formal_bundle_sha256": recovery_contract["source"][
            "bundle_sha256"
        ],
        "members": member_hashes,
        "formal_training_rerun_forbidden": True,
    }
    payload_bytes = deployment_common.canonical_json_bytes(payload)
    archive_tools.write_deterministic_archive(
        archive_path,
        members,
        virtual_members={PAYLOAD_MANIFEST_NAME: payload_bytes},
    )
    external = {
        "schema_version": "tukf20_hpc_verifier_recovery_bundle_manifest_v1",
        "recovery_id": RECOVERY_ID,
        "scientific_experiment_id": SCIENTIFIC_EXPERIMENT_ID,
        "archive_name": ARCHIVE_NAME,
        "archive_sha256": deployment_common.sha256_file(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "payload_manifest_name": PAYLOAD_MANIFEST_NAME,
        "payload_manifest_sha256": deployment_common.sha256_bytes(payload_bytes),
        "member_count": len(member_hashes),
        "members": member_hashes,
        "formal_training_rerun_forbidden": True,
    }
    deployment_common.write_new_json(manifest_path, external)
    archive_tools.verify_archive_against_manifest(archive_path, external)
    return {
        **external,
        "archive_path": archive_path,
        "manifest_path": manifest_path,
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    report = build_bundle(args.output_root)
    print(
        json.dumps(
            {
                "status": "TUKF20_VERIFIER_RECOVERY_BUNDLE_COMPLETE",
                "archive": str(report["archive_path"]),
                "archive_sha256": report["archive_sha256"],
                "archive_bytes": report["archive_bytes"],
                "member_count": report["member_count"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
