"""Independently verify TUKF20 without importing its runner or trainer."""
from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf20_hbv_rolling_origin_joint_learning_common as common  # noqa: E402
from scripts import verify_tukf17_hbv_rolling_origin_state_hydrology_update as numerical_reference  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
ABSOLUTE_TOLERANCE = 1e-11
RELATIVE_TOLERANCE = 1e-10
PERSISTED_READOUT_ARRAY_NAMES = frozenset(
    {
        "origins",
        "forecasts",
        "clean_targets",
        "observed_targets",
        "origin_states",
        "standardized_state_error",
        "complete_state_error_by_origin",
        "prior_origin_states",
        "prior_standardized_state_error",
        "prior_complete_state_error_by_origin",
        "prior_origin_covariances",
        "posterior_origin_covariances",
        "prior_counterfactual_forecasts",
        "prior_counterfactual_clean_squared_error",
        "posterior_counterfactual_clean_squared_error",
    }
)

# These two routines independently reconstruct the causal filter/readout and its
# scalar metrics.  Point their audited numerical primitives at the TUKF20 contract.
numerical_reference.common = common


def _load_npz(path: Path | str) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def _arrays_close(left: Any, right: Any) -> bool:
    a = np.asarray(left)
    b = np.asarray(right)
    if a.shape != b.shape or a.dtype.kind != b.dtype.kind:
        return False
    if a.dtype.kind in "fc":
        return bool(
            np.allclose(
                a,
                b,
                rtol=RELATIVE_TOLERANCE,
                atol=ABSOLUTE_TOLERANCE,
                equal_nan=False,
            )
        )
    return bool(np.array_equal(a, b))


def _arrays_byte_equal(left: Any, right: Any) -> bool:
    a = np.ascontiguousarray(np.asarray(left))
    b = np.ascontiguousarray(np.asarray(right))
    return a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes()


def _persisted_readout_arrays(
    reconstructed: Mapping[str, Any],
) -> dict[str, np.ndarray]:
    """Select the arrays written by the formal runner, excluding metric helpers."""

    missing = PERSISTED_READOUT_ARRAY_NAMES - set(reconstructed)
    if missing:
        raise ValueError(f"independent reconstruction is missing arrays: {sorted(missing)}")
    return {
        name: np.asarray(reconstructed[name])
        for name in sorted(PERSISTED_READOUT_ARRAY_NAMES)
    }


def _safe_child(root: Path, raw: Any) -> Path:
    value = Path(str(raw))
    if value.is_absolute() or ".." in value.parts:
        raise ValueError(f"unsafe evidence path: {raw}")
    resolved_root = root.resolve()
    candidate = (resolved_root / value).resolve()
    try:
        candidate.relative_to(resolved_root)
    except ValueError as error:
        raise ValueError(f"evidence path escapes its registered root: {raw}") from error
    return candidate


def _values_close(left: Any, right: Any) -> bool:
    if isinstance(left, Mapping) and isinstance(right, Mapping):
        return set(left) == set(right) and all(
            _values_close(left[key], right[key]) for key in left
        )
    if isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)):
        return len(left) == len(right) and all(
            _values_close(a, b) for a, b in zip(left, right)
        )
    if isinstance(left, (int, float, np.number)) and isinstance(
        right, (int, float, np.number)
    ):
        return math.isclose(
            float(left),
            float(right),
            rel_tol=RELATIVE_TOLERANCE,
            abs_tol=ABSOLUTE_TOLERANCE,
        )
    return left == right


def independently_select_checkpoint(
    rows: Sequence[Mapping[str, Any]], *, trainable: bool
) -> dict[str, Any]:
    if not rows:
        raise ValueError("selection rows are empty")
    values = [
        {"update": int(row["update"]), "selection_loss": float(row["selection_loss"])}
        for row in rows
    ]
    expected = tuple(range(0, 97, 4)) if trainable else (0,)
    if tuple(row["update"] for row in values) != expected:
        raise ValueError("selection rows do not match the frozen query schedule")
    if not all(
        math.isfinite(row["selection_loss"]) and row["selection_loss"] >= 0.0
        for row in values
    ):
        raise ValueError("selection loss is non-finite or negative")
    return min(values, key=lambda row: (row["selection_loss"], row["update"]))


def _tensor_inputs(
    contract: Mapping[str, Any], forcing: np.ndarray, observations: np.ndarray
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    return (
        torch.as_tensor(forcing, dtype=torch.float64),
        torch.as_tensor(observations, dtype=torch.float64),
        torch.as_tensor(contract["truth_and_filter"]["initial_state"], dtype=torch.float64),
        torch.eye(8, dtype=torch.float64)
        * float(contract["truth_and_filter"]["initial_covariance_diagonal"]),
    )


def _independent_balance_errors(
    contract: Mapping[str, Any], registry: Mapping[str, Any]
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    pairs = common.registered_pairs(contract, registry)
    result = {
        name: np.empty((27, 2, 3), dtype=np.float64)
        for name in ("E00", "E01", "E10", "E11")
    }
    definitions = {
        "E00": ("truth", "truth"),
        "E01": ("truth", "initial"),
        "E10": ("initial", "truth"),
        "E11": ("initial", "initial"),
    }
    for pair_index, (seed, start_id) in enumerate(pairs):
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        observations = np.asarray(truth["observations"], dtype=np.float64)
        tensors = _tensor_inputs(contract, forcing, observations)
        for label, (hydrology_source, filter_source) in definitions.items():
            model = common.build_model(
                contract,
                start_id,
                hydrology_source=hydrology_source,
                filter_source=filter_source,
            )
            for window_index, split in enumerate(("train", "selection")):
                with torch.no_grad():
                    _, details = common.rolling_origin_objective(
                        model,
                        *tensors,
                        common.origin_indices(contract, split),
                        state_update=True,
                        targets=tensors[1],
                        base_observation_variance=float(
                            contract["truth_and_filter"]["base_observation_variance"]
                        ),
                    )
                result[label][pair_index, window_index] = [
                    float(details["mse_by_lead"][lead]) for lead in common.LEADS
                ]
    return result["E00"], result["E01"], result["E10"], result["E11"]


def verify_preflight(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    common.validate_contract(contract, configuration_path=contract_path)
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    preflight = common.read_json(root / "preflight.json")
    seed_registry = common.read_json(root / "seed_registry.json")
    stored_balance = common.read_json(root / "balance_gate.json")
    stored_errors = _load_npz(root / "balance_errors.npz")
    attempted = seed_registry.get("attempted_candidates", [])
    seed_checks = []
    for stored in attempted:
        recomputed = common.mechanically_accept_truth_seed(int(stored["seed"]), contract)
        seed_checks.append(
            all(
                _values_close(stored.get(key), recomputed.get(key))
                for key in (
                    "seed",
                    "accepted",
                    "checks",
                    "diagnostics",
                    "scientific_metric_queries",
                    "truth_array_sha256",
                    "generation_error",
                )
            )
        )
    pairs = common.registered_pairs(contract, seed_registry)
    accepted_attempts = [row for row in attempted if bool(row["accepted"])][:27]
    expected_pairs = [
        {
            "accepted_order": index,
            "truth_seed": int(row["seed"]),
            "start_id": common.START_IDS[index - 1],
            "truth_array_sha256": row.get("truth_array_sha256"),
        }
        for index, row in enumerate(accepted_attempts, 1)
    ]
    e00, e01, e10, e11 = _independent_balance_errors(contract, seed_registry)
    recomputed_balance = common.classify_balance_arrays(
        e00, e01, e10, e11, contract
    )
    attempted_seeds = {int(row["seed"]) for row in attempted}
    prior_seeds = set(range(1701, 1731)) | set(range(1801, 1833))
    checks = {
        "preflight_identity": preflight.get("schema_version")
        == "tukf20_engineering_preflight_v1"
        and preflight.get("experiment_id") == common.EXPERIMENT_ID
        and seed_registry.get("schema_version")
        == "tukf20_truth_seed_registry_v1"
        and seed_registry.get("experiment_id") == common.EXPERIMENT_ID,
        "configuration_identity": preflight.get("configuration_sha256")
        == common.sha256_file(contract_path),
        "source_identity": preflight.get("source_sha256")
        == common.source_hashes(contract, configuration_path=contract_path),
        "seed_attempts_recomputed": bool(seed_checks) and all(seed_checks),
        "accepted_seed_assignment_recomputed": _values_close(
            seed_registry.get("accepted_pairs"), expected_pairs
        ),
        "accepted_seed_count_and_independence": len(pairs) == 27
        and len({seed for seed, _ in pairs}) == 27,
        "new_seed_interval_and_prior_disjointness": bool(attempted_seeds)
        and min(attempted_seeds) >= 1901
        and attempted_seeds.isdisjoint(prior_seeds),
        "zero_scientific_queries_during_seed_selection": int(
            seed_registry.get("scientific_metric_queries", -1)
        )
        == 0,
        "balance_e00_raw_arrays": set(stored_errors) == {"E00", "E01", "E10", "E11"}
        and _arrays_close(stored_errors["E00"], e00),
        "balance_e01_raw_arrays": _arrays_close(stored_errors["E01"], e01),
        "balance_e10_raw_arrays": _arrays_close(stored_errors["E10"], e10),
        "balance_e11_raw_arrays": _arrays_close(stored_errors["E11"], e11),
        "balance_artifact_hashes": preflight.get("balance_errors_sha256")
        == common.sha256_file(root / "balance_errors.npz")
        and preflight.get("balance_gate_sha256")
        == common.sha256_file(root / "balance_gate.json")
        and preflight.get("seed_registry_sha256")
        == common.sha256_file(root / "seed_registry.json"),
        "balance_classification_recomputed": _values_close(
            stored_balance, recomputed_balance
        ),
        "preflight_status_matches_balance": preflight.get("status")
        == (
            "PREFLIGHT_ENGINEERING_PASS"
            if recomputed_balance["status"] == "BALANCE_PASS"
            else "BALANCE_HOLD"
        ),
        "no_test_queries": int(preflight.get("test_metric_queries", -1)) == 0
        and int(preflight.get("clean_test_target_queries", -1)) == 0,
        "no_formal_optimizer_updates": int(
            preflight.get("formal_optimizer_updates", -1)
        )
        == 0,
    }
    if all(checks.values()) and recomputed_balance["status"] == "BALANCE_PASS":
        status = "PREFLIGHT_VERIFIED"
    elif all(checks.values()):
        status = "BALANCE_HOLD_VERIFIED"
    else:
        status = "PREFLIGHT_VERIFICATION_FAILED"
    report = {
        "schema_version": "tukf20_independent_preflight_verification_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": status,
        "checks": checks,
        "balance_status": recomputed_balance["status"],
        "accepted_seed_count": len(pairs),
        "test_metric_queries": 0,
        "formal_optimizer_updates": 0,
    }
    common.write_new_json(root / "independent_verification.json", report)
    return report


def _verify_manifest(root: Path, manifest: Mapping[str, Any]) -> bool:
    expected = {
        path.relative_to(root).as_posix(): common.sha256_file(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
        and path.name not in {"manifest.json", "independent_verification.json"}
    }
    return (
        manifest.get("schema_version") == "tukf20_root_manifest_v1"
        and manifest.get("experiment_id") == common.EXPERIMENT_ID
        and manifest.get("files") == expected
    )


def _selection_loss(
    contract: Mapping[str, Any],
    model: Any,
    forcing: np.ndarray,
    observations: np.ndarray,
) -> tuple[float, dict[str, float]]:
    supplied_end = max(common.origin_indices(contract, "selection")) + max(common.LEADS) + 1
    tensors = _tensor_inputs(
        contract,
        np.ascontiguousarray(forcing[:supplied_end]),
        np.ascontiguousarray(observations[:supplied_end]),
    )
    with torch.no_grad():
        loss, details = common.rolling_origin_objective(
            model,
            *tensors,
            common.origin_indices(contract, "selection"),
            state_update=True,
            targets=tensors[1],
            base_observation_variance=float(
                contract["truth_and_filter"]["base_observation_variance"]
            ),
        )
    return float(loss), {
        str(lead): float(details["mse_by_lead"][lead]) for lead in common.LEADS
    }


def _group_keys(group: str) -> tuple[str, ...]:
    if group == "hydrology":
        return ("hydrology", "physical_parameters")
    if group == "filter":
        return (
            "log_process",
            "log_observation",
            "process_diagonal",
            "observation_ratio",
        )
    raise ValueError(group)


def _mode_mask(contract: Mapping[str, Any], mode: str) -> dict[str, bool]:
    expected = {
        "all_frozen": {"hydrology": False, "filter": False},
        "hydrology_only": {"hydrology": True, "filter": False},
        "filter_only": {"hydrology": False, "filter": True},
        "joint": {"hydrology": True, "filter": True},
    }
    if mode not in expected:
        raise ValueError(f"unknown mode: {mode}")
    actual = {
        "hydrology": bool(contract["mode_masks"][mode]["hydrology"]),
        "filter": bool(contract["mode_masks"][mode]["filter"]),
    }
    if actual != expected[mode]:
        raise ValueError(f"trainability mask changed for {mode}")
    return actual


def _verify_selection_cells(
    root: Path,
    contract: Mapping[str, Any],
    pairs: Sequence[tuple[int, str]],
    seal: Mapping[str, Any],
) -> tuple[bool, dict[tuple[int, str, str], dict[str, np.ndarray]], int, int]:
    expected = {(seed, start, mode) for seed, start in pairs for mode in common.MODE_ORDER}
    cells = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row.get("mode", row.get("method")))): row
        for row in seal.get("cells", [])
    }
    if set(cells) != expected:
        return False, {}, 0, 0
    budget = contract["seals_and_budget"]
    all_checks = (
        seal.get("schema_version") == "tukf20_global_selection_seal_v1"
        and seal.get("experiment_id") == common.EXPERIMENT_ID
        and seal.get("status") == "GLOBAL_SELECTION_SEALED"
        and int(seal.get("completed_mode_checkpoints", -1))
        == int(budget["selected_checkpoints"])
        and int(seal.get("completed_method_checkpoints", -1))
        == int(budget["selected_checkpoints"])
        and int(seal.get("optimizer_step_count", -1))
        == int(budget["real_optimizer_updates"])
        and int(seal.get("selection_query_count", -1))
        == int(budget["selection_queries"])
        and int(seal.get("test_observation_inputs_before_seal", -1)) == 0
        and int(seal.get("clean_target_queries_before_seal", -1)) == 0
        and seal.get("source_sha256") == common.source_hashes(contract)
    )
    selected_snapshots: dict[tuple[int, str, str], dict[str, np.ndarray]] = {}
    optimizer_steps = 0
    selection_queries = 0
    for seed, start_id in pairs:
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        observations = np.asarray(truth["observations"], dtype=np.float64)
        for mode in common.MODE_ORDER:
            identity = (seed, start_id, mode)
            sealed_cell = cells[identity]
            mode_root = root / "repetitions" / f"truth_{seed}__{start_id}" / "modes" / mode
            history = common.read_json(mode_root / "history.json")
            mask = _mode_mask(contract, mode)
            trainable = bool(mask["hydrology"] or mask["filter"])
            expected_steps = int(contract["optimizer"]["updates"]) if trainable else 0
            expected_queries = len(contract["selection"]["query_updates"]) if trainable else 1
            training_updates = tuple(
                int(row["update"]) for row in history.get("training_rows", ())
            )
            all_checks &= (
                history.get("schema_version") == "tukf20_mode_training_history_v1"
                and history.get("experiment_id") == common.EXPERIMENT_ID
                and history.get("mode") == mode
                and history.get("state_update") is True
                and history.get("active_groups")
                == [name for name in ("hydrology", "filter") if bool(mask[name])]
                and int(history.get("optimizer_step_count", -1)) == expected_steps
                and int(history.get("real_optimizer_step_count", -1)) == expected_steps
                and int(history.get("selection_query_count", -1)) == expected_queries
                and training_updates
                == (tuple(range(1, expected_steps + 1)) if trainable else ())
                and len(history.get("selection_rows", ())) == expected_queries
                and int(history.get("test_observation_input_count", -1)) == 0
                and int(history.get("clean_target_query_count", -1)) == 0
            )
            independent_choice = independently_select_checkpoint(
                history["selection_rows"], trainable=trainable
            )
            initial_snapshot: dict[str, np.ndarray] | None = None
            snapshots: dict[int, dict[str, np.ndarray]] = {}
            recomputed_rows: list[dict[str, Any]] = []
            for row in history["selection_rows"]:
                update = int(row["update"])
                checkpoint = _safe_child(mode_root, row["checkpoint_file"])
                snapshot = _load_npz(checkpoint)
                snapshots[update] = snapshot
                if update == 0:
                    initial_snapshot = snapshot
                model = common.build_model(contract, start_id)
                common.restore_model_(model, snapshot)
                loss, by_lead = _selection_loss(
                    contract, model, forcing, observations
                )
                recomputed_rows.append({"update": update, "selection_loss": loss})
                all_checks &= common.sha256_file(checkpoint) == str(
                    row["checkpoint_file_sha256"]
                )
                all_checks &= common.sha256_arrays(snapshot) == str(
                    row["snapshot_sha256"]
                )
                all_checks &= math.isclose(
                    loss,
                    float(row["selection_loss"]),
                    rel_tol=RELATIVE_TOLERANCE,
                    abs_tol=ABSOLUTE_TOLERANCE,
                )
                all_checks &= _values_close(by_lead, row["selection_mse_by_lead"])
            if initial_snapshot is None:
                all_checks = False
                continue
            choice = independently_select_checkpoint(recomputed_rows, trainable=trainable)
            all_checks &= choice["update"] == independent_choice["update"]
            all_checks &= choice["update"] == int(history["selected"]["update"])
            selected = _load_npz(mode_root / "selected_checkpoint.npz")
            chosen_snapshot = snapshots[choice["update"]]
            all_checks &= set(selected) == set(chosen_snapshot) and all(
                _arrays_byte_equal(selected[name], chosen_snapshot[name])
                for name in selected
            )
            selected_file = mode_root / "selected_checkpoint.npz"
            selected_file_hash = common.sha256_file(selected_file)
            selected_snapshot_hash = common.sha256_arrays(selected)
            all_checks &= (
                selected_file_hash == str(history["selected_checkpoint_sha256"])
                and selected_snapshot_hash == str(history["selected_snapshot_sha256"])
                and sealed_cell
                == {
                    "truth_seed": seed,
                    "start_id": start_id,
                    "mode": mode,
                    "state_update": True,
                    "selected_update": int(choice["update"]),
                    "selected_selection_loss": float(
                        history["selected"]["selection_loss"]
                    ),
                    "selected_snapshot_sha256": selected_snapshot_hash,
                    "checkpoint_path": selected_file.relative_to(root).as_posix(),
                    "checkpoint_file_sha256": selected_file_hash,
                }
            )
            for group in ("hydrology", "filter"):
                if not bool(mask[group]):
                    all_checks &= all(
                        _arrays_byte_equal(snapshot[name], initial_snapshot[name])
                        for snapshot in snapshots.values()
                        for name in _group_keys(group)
                    )
            all_checks &= all(
                _arrays_byte_equal(snapshot[name], initial_snapshot[name])
                for snapshot in snapshots.values()
                for name in ("lag_time", "state_dimension")
            )
            selected_snapshots[(seed, start_id, mode)] = selected
            optimizer_steps += int(history["optimizer_step_count"])
            selection_queries += int(history["selection_query_count"])
    all_checks &= optimizer_steps == int(budget["real_optimizer_updates"])
    all_checks &= selection_queries == int(budget["selection_queries"])
    return all_checks, selected_snapshots, optimizer_steps, selection_queries


def _tail_fraction(successes: int, trials: int) -> Fraction:
    return Fraction(
        sum(math.comb(trials, value) for value in range(successes, trials + 1)),
        2**trials,
    )


def _binomial_cdf(successes: int, trials: int, probability: float) -> float:
    return sum(
        math.comb(trials, value)
        * probability**value
        * (1.0 - probability) ** (trials - value)
        for value in range(successes + 1)
    )


def _clopper_pearson(
    successes: int, trials: int, alpha: float = 0.05
) -> list[float]:
    if successes == 0:
        lower = 0.0
    else:
        low, high = 0.0, 1.0
        for _ in range(100):
            midpoint = 0.5 * (low + high)
            upper_tail = 1.0 - _binomial_cdf(
                successes - 1, trials, midpoint
            )
            if upper_tail < alpha / 2.0:
                low = midpoint
            else:
                high = midpoint
        lower = 0.5 * (low + high)
    if successes == trials:
        upper = 1.0
    else:
        low, high = 0.0, 1.0
        for _ in range(100):
            midpoint = 0.5 * (low + high)
            lower_tail = _binomial_cdf(successes, trials, midpoint)
            if lower_tail > alpha / 2.0:
                low = midpoint
            else:
                high = midpoint
        upper = 0.5 * (low + high)
    return [lower, upper]


def _contrast(
    indexed: Mapping[tuple[int, str, str], Mapping[str, Any]],
    pairs: Sequence[tuple[int, str]],
    numerator: str,
    denominator: str,
    contract: Mapping[str, Any],
) -> dict[str, Any]:
    ratios = [
        float(indexed[(seed, start, numerator)]["primary_clean_mse"])
        / float(indexed[(seed, start, denominator)]["primary_clean_mse"])
        for seed, start in pairs
    ]
    wins = int(np.count_nonzero(np.asarray(ratios) < 1.0))
    losses = int(np.count_nonzero(np.asarray(ratios) > 1.0))
    benefit_tail = _tail_fraction(wins, len(ratios))
    harm_tail = _tail_fraction(losses, len(ratios))
    median = float(np.median(ratios))
    minimum = int(contract["gates"]["minimum_direction_count"])
    alpha = float(contract["gates"]["sign_test_one_sided_alpha"])
    if (
        median <= float(contract["gates"]["clear_benefit_median_ratio_maximum"])
        and wins >= minimum
        and float(benefit_tail) <= alpha
    ):
        classification = "CLEAR_BENEFIT"
    elif (
        median >= float(contract["gates"]["clear_harm_median_ratio_minimum"])
        and losses >= minimum
        and float(harm_tail) <= alpha
    ):
        classification = "CLEAR_HARM"
    elif wins >= minimum or losses >= minimum:
        classification = "DIRECTIONAL_SMALL"
    else:
        classification = "MIXED_OR_INCONCLUSIVE"
    by_lead: dict[str, Any] = {}
    for lead in common.LEADS:
        values = [
            float(indexed[(seed, start, numerator)]["primary_clean_mse_by_lead"][str(lead)])
            / float(indexed[(seed, start, denominator)]["primary_clean_mse_by_lead"][str(lead)])
            for seed, start in pairs
        ]
        lead_values = np.asarray(values, dtype=np.float64)
        lead_wins = int(np.count_nonzero(lead_values < 1.0))
        lead_losses = int(np.count_nonzero(lead_values > 1.0))
        by_lead[str(lead)] = {
            "median_ratio": float(np.median(values)),
            "ratio_range": [min(values), max(values)],
            "wins_below_one": lead_wins,
            "losses_above_one": lead_losses,
            "ties_at_one": len(values) - lead_wins - lead_losses,
            "ratios": values,
        }
    return {
        "numerator": numerator,
        "denominator": denominator,
        "per_pair_ratios": [
            {"truth_seed": seed, "start_id": start, "ratio": ratio}
            for (seed, start), ratio in zip(pairs, ratios)
        ],
        "ratios": ratios,
        "median_ratio": median,
        "ratio_range": [min(ratios), max(ratios)],
        "wins_below_one": wins,
        "losses_above_one": losses,
        "ties_at_one": len(ratios) - wins - losses,
        "win_fraction_exact_95_percent_interval": _clopper_pearson(
            wins, len(ratios)
        ),
        "benefit_sign_test_one_sided_p": float(benefit_tail),
        "benefit_sign_test_fraction": [benefit_tail.numerator, benefit_tail.denominator],
        "harm_sign_test_one_sided_p": float(harm_tail),
        "harm_sign_test_fraction": [harm_tail.numerator, harm_tail.denominator],
        "classification": classification,
        "by_lead": by_lead,
    }


def independently_aggregate(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    row_values = tuple(rows)
    if len(row_values) != 108:
        raise ValueError("independent aggregate requires exactly 108 readout rows")
    indexed = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row["readout_id"])): row
        for row in row_values
    }
    if len(indexed) != len(row_values):
        raise ValueError("independent aggregate rejects duplicate readout rows")
    pairs = tuple(
        sorted(
            {(seed, start) for seed, start, _ in indexed},
            key=lambda pair: common.START_IDS.index(pair[1]),
        )
    )
    expected = {(seed, start, mode) for seed, start in pairs for mode in common.READOUT_ORDER}
    if len(pairs) != 27 or set(indexed) != expected:
        raise ValueError("independent aggregate requires 108 complete readout rows")
    primary_contrasts = {
        name: _contrast(
            indexed,
            pairs,
            str(spec["numerator"]),
            str(spec["denominator"]),
            contract,
        )
        for name, spec in contract["primary_contrasts"].items()
    }
    interaction: list[float] = []
    interaction_rows: list[dict[str, Any]] = []
    for seed, start in pairs:
        values = {
            mode: float(indexed[(seed, start, mode)]["primary_clean_mse"])
            for mode in common.MODE_ORDER
        }
        ratio = (values["joint"] * values["all_frozen"]) / (
            values["hydrology_only"] * values["filter_only"]
        )
        interaction.append(ratio)
        interaction_rows.append(
            {
                "truth_seed": seed,
                "start_id": start,
                "interaction_ratio": ratio,
                "log_interaction_ratio": math.log(ratio),
            }
        )
    interaction_values = np.asarray(interaction, dtype=np.float64)
    below = int(np.count_nonzero(interaction_values < 1.0))
    above = int(np.count_nonzero(interaction_values > 1.0))
    alpha = float(contract["gates"]["sign_test_one_sided_alpha"])
    primary = {
        "independent_unit": "unique_truth_seed_and_registered_start_pair",
        "independent_unit_count": 27,
        "contrasts": primary_contrasts,
        "interaction": {
            "formula": contract["two_factor_interaction"]["formula"],
            "descriptive_only": True,
            "causal_or_success_gate": False,
            "per_pair": interaction_rows,
            "median_ratio": float(np.median(interaction)),
            "ratio_range": [min(interaction), max(interaction)],
            "below_one_count": below,
            "above_one_count": above,
            "ties_at_one": len(interaction) - below - above,
            "below_one_fraction_exact_95_percent_interval": _clopper_pearson(
                below, len(interaction), alpha
            ),
            "above_one_fraction_exact_95_percent_interval": _clopper_pearson(
                above, len(interaction), alpha
            ),
        },
    }
    crossed = {
        name: _contrast(
            indexed,
            pairs,
            str(spec["numerator"]),
            str(spec["denominator"]),
            contract,
        )
        for name, spec in contract["secondary_contrasts"].items()
    }
    return primary, crossed


def verify_formal(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    common.validate_contract(contract, configuration_path=contract_path)
    preflight_root = common.resolve_output_path(
        contract, contract["outputs"]["preflight_root"]
    )
    preflight_verification = common.read_json(
        preflight_root / "independent_verification.json"
    )
    if preflight_verification.get("status") != "PREFLIGHT_VERIFIED":
        raise PermissionError("formal verification requires verified preflight")
    root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    registry = common.read_json(root / "registry.json")
    manifest = common.read_json(root / "manifest.json")
    seal = common.read_json(root / "selection_seal.json")
    pairs = common.registered_pairs(
        contract, common.read_json(preflight_root / "seed_registry.json")
    )
    selection_ok, snapshots, optimizer_steps, selection_queries = _verify_selection_cells(
        root, contract, pairs, seal
    )
    registry_rows = tuple(registry.get("rows", ()))
    if len(registry_rows) != 108:
        raise ValueError("formal registry must contain exactly 108 readout rows")
    stored_rows = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row["readout_id"])): row
        for row in registry_rows
    }
    expected_row_keys = {
        (seed, start_id, readout_id)
        for seed, start_id in pairs
        for readout_id in common.READOUT_ORDER
    }
    if len(stored_rows) != len(registry_rows) or set(stored_rows) != expected_row_keys:
        raise ValueError("formal registry readout identities are duplicate or incomplete")
    reconstructed_rows: list[dict[str, Any]] = []
    truth_checks: list[bool] = []
    array_checks: list[bool] = []
    metric_checks: list[bool] = []
    pair_metric_checks: list[bool] = []
    clean_error_count = 0
    for seed, start_id in pairs:
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        pair_root = root / "repetitions" / f"truth_{seed}__{start_id}"
        stored_truth = _load_npz(pair_root / "truth_arrays.npz")
        expected_truth = {
            name: value for name, value in truth.items() if isinstance(value, np.ndarray)
        }
        truth_checks.append(
            set(stored_truth) == set(expected_truth)
            and all(_arrays_close(stored_truth[name], value) for name, value in expected_truth.items())
        )
        rebuilt_pair_rows: list[dict[str, Any]] = []
        for readout_id in common.READOUT_ORDER:
            source_mode = str(
                contract["readout_grid"][readout_id]["parameter_source_pipeline"]
            )
            snapshot = snapshots[(seed, start_id, source_mode)]
            model = common.build_model(contract, start_id)
            common.restore_model_(model, snapshot)
            for parameter in (
                model.hydrology_coordinates,
                model.log_process_diagonal,
                model.log_observation_ratio,
            ):
                parameter.requires_grad_(False)
            frozen_snapshot_hash = common.sha256_arrays(common.snapshot_model(model))
            rebuilt = numerical_reference._stream_reconstruct(
                contract, model, readout_id, forcing, truth
            )
            if common.sha256_arrays(common.snapshot_model(model)) != frozen_snapshot_hash:
                raise RuntimeError("independent test reconstruction mutated the model")
            recomputed = numerical_reference._recomputed_row(
                seed, start_id, readout_id, rebuilt, contract
            )
            readout_root = pair_root / "readouts" / readout_id
            stored_arrays = _load_npz(readout_root / "arrays.npz")
            rebuilt_arrays = _persisted_readout_arrays(rebuilt)
            array_checks.append(
                set(stored_arrays) == set(rebuilt_arrays)
                and all(
                    _arrays_close(stored_arrays[name], rebuilt_arrays[name])
                    for name in rebuilt_arrays
                )
            )
            stored_metric_file = common.read_json(readout_root / "metrics.json")
            stored_registry_row = stored_rows[(seed, start_id, readout_id)]
            expected_augmented = {
                **recomputed,
                "arrays_sha256": common.sha256_file(readout_root / "arrays.npz"),
                "parameter_snapshot_sha256": frozen_snapshot_hash,
            }
            metric_checks.append(
                _values_close(stored_metric_file, expected_augmented)
                and _values_close(stored_registry_row, expected_augmented)
            )
            reconstructed_rows.append(expected_augmented)
            rebuilt_pair_rows.append(expected_augmented)
            clean_error_count += int(recomputed["primary_clean_error_count"])
        pair_metric_checks.append(
            _values_close(
                common.read_json(pair_root / "pair_metrics.json"),
                {
                    "schema_version": "tukf20_pair_metrics_v1",
                    "truth_seed": seed,
                    "start_id": start_id,
                    "readouts": rebuilt_pair_rows,
                },
            )
        )
    primary, crossed = independently_aggregate(reconstructed_rows, contract)
    independent_aggregate = {"primary": primary, "crossed": crossed}
    primary_classes = {
        name: value["classification"] for name, value in primary["contrasts"].items()
    }
    overall_status = (
        "FINAL_JOINT_ADVANTAGE_ESTABLISHED"
        if primary_classes
        and all(value == "CLEAR_BENEFIT" for value in primary_classes.values())
        else "FINAL_JOINT_ADVANTAGE_NOT_ESTABLISHED"
    )
    expected_science = {
        "overall_status": overall_status,
        "primary_classes": primary_classes,
        "secondary_classes": {
            name: value["classification"] for name, value in crossed.items()
        },
        "all_primary_clear_benefit": overall_status
        == "FINAL_JOINT_ADVANTAGE_ESTABLISHED",
        "two_factor_interaction_descriptive_only": True,
        "scientific_retuning_allowed": False,
    }
    checks = {
        "preflight_verified": preflight_verification.get("status") == "PREFLIGHT_VERIFIED",
        "formal_registry_identity": registry.get("schema_version")
        == "tukf20_formal_registry_v1"
        and registry.get("experiment_id") == common.EXPERIMENT_ID
        and registry.get("status")
        == "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION",
        "manifest_verified": _verify_manifest(root, manifest),
        "source_identity_at_start": registry.get("source_sha256_start")
        == common.source_hashes(contract, configuration_path=contract_path),
        "source_identity_at_end": registry.get("source_sha256_end")
        == common.source_hashes(contract, configuration_path=contract_path),
        "selection_seal_identity": registry.get("selection_seal_sha256")
        == common.sha256_file(root / "selection_seal.json"),
        "selection_checkpoints_independently_verified": selection_ok,
        "optimizer_budget_verified": optimizer_steps
        == int(contract["seals_and_budget"]["real_optimizer_updates"]),
        "selection_query_budget_verified": selection_queries
        == int(contract["seals_and_budget"]["selection_queries"]),
        "truth_arrays_recomputed": len(truth_checks) == 27 and all(truth_checks),
        "all_readout_arrays_recomputed": len(array_checks) == 108 and all(array_checks),
        "all_metric_rows_recomputed": len(metric_checks) == 108 and all(metric_checks),
        "all_pair_metric_products_recomputed": len(pair_metric_checks) == 27
        and all(pair_metric_checks),
        "clean_error_budget_verified": clean_error_count == 13608,
        "aggregates_independently_recomputed": _values_close(
            registry.get("aggregates"), independent_aggregate
        ),
        "scientific_classification_recomputed": _values_close(
            registry.get("scientific_classification"), expected_science
        ),
        "resource_admission_recorded": registry.get("resource_admission", {}).get(
            "status"
        )
        == "RESOURCE_ADMITTED"
        and bool(registry.get("resource_admission", {}).get("checks"))
        and all(
            bool(value)
            for value in registry.get("resource_admission", {})
            .get("checks", {})
            .values()
        ),
        "claims_boundary_unchanged": registry.get("claims_not_authorized")
        == contract["claims_not_authorized"],
        "no_test_period_parameter_updates": all(
            int(row["online_parameter_update_count"]) == 0 for row in reconstructed_rows
        ),
        "all_test_readouts_use_state_updates": all(
            bool(row["state_update"]) for row in reconstructed_rows
        ),
    }
    status = "FORMAL_VERIFIED" if all(checks.values()) else "FORMAL_VERIFICATION_FAILED"
    report = {
        "schema_version": "tukf20_formal_independent_verification_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": status,
        "checks": checks,
        "optimizer_step_count": optimizer_steps,
        "selection_query_count": selection_queries,
        "test_readout_count": len(reconstructed_rows),
        "primary_clean_error_count": clean_error_count,
        "registry_sha256": common.sha256_file(root / "registry.json"),
        "root_manifest_sha256": common.sha256_file(root / "manifest.json"),
        "selection_seal_sha256": common.sha256_file(root / "selection_seal.json"),
        "independent_aggregates": independent_aggregate,
        "scientific_classification": expected_science,
        "technical_verification_is_not_scientific_success": True,
    }
    common.write_new_json(root / "independent_verification.json", report)
    return report


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("preflight", "formal"), required=True)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    report = (
        verify_preflight(contract, contract_path=contract_path)
        if args.stage == "preflight"
        else verify_formal(contract, contract_path=contract_path)
    )
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, allow_nan=False))
    return 0 if report["status"] in {"PREFLIGHT_VERIFIED", "FORMAL_VERIFIED"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
